// ============================================================
// STUDIO J V-CAM — voice.js  v1.2.0
// ボイスチェンジャー（Web Audio API）
//   マイク → HPF → ピッチシフト → [ロボ変調] → EQ(太さ) → コンプ → 出力
// 音声はすべて端末内で処理。外部送信・録画なし。
// ============================================================
//
// 【v1.2.0 品質修正メモ】
//  ・旧実装は読み出し位置がオーディオブロック(128sample)ごとに飛ぶバグがあり、
//    約375Hzの金属的なバズ（＝犯罪者ボイチェン音）が常時乗っていた。
//  ・修正版は「ノコギリ波でディレイタイムを掃引する2タップ方式」。
//    書き込みと読み出しを1サンプルずつ交互に行うので、ブロック境界で飛ばない。
//    タップの折り返し瞬間は窓関数のゲインが必ず0（クリックが出ない）。
//    Hann窓の半周期ずらし2枚は合計が常に1（音量ムラなし）。
//  ・「フォルマント」廃止 →「太さ」(EQシェルフ)に変更。
//    旧実装のフォルマントはピッチに掛け算されるだけの偽物で、
//    シフト量が深くなりすぎて音が崩れる原因だった。
//    EQは原理的にアーティファクトゼロで、声の印象は十分変わる。

// ---- AudioWorklet のソース（Blob URL 読み込み・単一ファイル配布のまま）----
const WORKLET_SRC = `
class PitchProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      { name: 'pitch', defaultValue: 1.0, minValue: 0.4, maxValue: 2.5, automationRate: 'k-rate' },
      { name: 'wet',   defaultValue: 1.0, minValue: 0.0, maxValue: 1.0, automationRate: 'k-rate' }
    ];
  }

  constructor() {
    super();
    this.size = 32768;                          // リングバッファ（約0.68s @48k）
    this.buf = new Float32Array(this.size);
    this.w = 0;                                 // 書き込み位置
    this.phase = 0;                             // ノコギリ波位相 0..1
    this.grain = Math.round(sampleRate * 0.05); // 掃引幅 50ms
    this.minLag = 64;                           // 最小ディレイ（先読み事故防止）
  }

  // 線形補間つき読み出し（ラップアラウンド対応）
  read(pos) {
    let p = pos % this.size;
    if (p < 0) p += this.size;
    const i0 = p | 0;
    const i1 = (i0 + 1) % this.size;
    const f = p - i0;
    return this.buf[i0] + (this.buf[i1] - this.buf[i0]) * f;
  }

  process(inputs, outputs, params) {
    const out = outputs[0];
    if (!out || out.length === 0) return true;
    const o = out[0];
    const n = o.length;
    const inp = (inputs[0] && inputs[0].length > 0) ? inputs[0][0] : null;
    if (!inp) {
      o.fill(0);
      for (let c = 1; c < out.length; c++) out[c].set(o);
      return true;
    }

    const speed = params.pitch[0];
    const wet = params.wet[0];
    const g = this.grain;
    const inc = (1 - speed) / g;   // ディレイ掃引の位相増分（サンプルあたり）

    for (let i = 0; i < n; i++) {
      // 書き込み（1サンプル）
      this.buf[this.w] = inp[i];
      this.w = (this.w + 1) % this.size;

      // ノコギリ波位相（speed>1 なら逆方向に回る）
      this.phase += inc;
      this.phase -= Math.floor(this.phase);   // 常に [0,1) へ

      const p1 = this.phase;
      const p2 = (this.phase + 0.5) % 1;
      const w1 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p1);
      const w2 = 1 - w1;                      // Hann半周期ずらしは合計＝1

      // ディレイタイム = minLag 〜 minLag+grain を掃引
      // d(読み出し位置)/dt = 1 - (掃引速度) = speed → 正しいピッチ比になる
      const d1 = this.minLag + p1 * g;
      const d2 = this.minLag + p2 * g;
      const s = this.read(this.w - 1 - d1) * w1 + this.read(this.w - 1 - d2) * w2;

      const y = s * wet + inp[i] * (1 - wet);
      o[i] = Math.tanh(y * 1.15) * 0.95;      // 軽いソフトクリップ
    }

    for (let c = 1; c < out.length; c++) out[c].set(o);
    return true;
  }
}
registerProcessor('pitch-processor', PitchProcessor);
`;

// ---- プリセット ----
// pitch: 声の高さ（1.0=素）/ tone: 太さ（+太く低域寄り / -細く明るく）
export const VOICE_PRESETS = {
  off:     { label: "🎤 素の声",       pitch: 1.00, tone:  0.0, robot: 0, wet: 0.0 },
  lowman:  { label: "🕶️ 低音イケメン", pitch: 0.84, tone: +0.5, robot: 0, wet: 1.0 },
  deep:    { label: "🌑 超低音",       pitch: 0.72, tone: +0.8, robot: 0, wet: 1.0 },
  high:    { label: "✨ 高め",         pitch: 1.18, tone: -0.3, robot: 0, wet: 1.0 },
  anime:   { label: "🎀 アニメ声",     pitch: 1.34, tone: -0.5, robot: 0, wet: 1.0 },
  robot:   { label: "🤖 ロボ風",       pitch: 0.92, tone: +0.2, robot: 1, wet: 1.0 },
  alien:   { label: "👾 エイリアン",   pitch: 1.25, tone: -0.4, robot: 1, wet: 1.0 }
};

export class VoiceChanger {
  constructor() {
    this.ctx = null;
    this.srcNode = null;
    this.stream = null;       // マイクの生ストリーム
    this.outStream = null;    // 加工後（配信ソフトへ渡す用）
    this.node = null;         // AudioWorkletNode または ScriptProcessorNode
    this.useWorklet = false;
    this.hp = null;           // ハイパス（マイクの吹かれ・ゴロゴロ除去）
    this.loShelf = null;      // 太さEQ 低域
    this.hiShelf = null;      // 太さEQ 高域
    this.comp = null;         // コンプレッサー（音量を均す）
    this.makeup = null;
    this.dest = null;
    this.monitorGain = null;
    this.analyser = null;
    this.ringMod = null;      // ロボ風用
    this.ringGain = null;
    this.running = false;
    this.params = { pitch: 1.0, tone: 0.0, robot: 0, wet: 1.0 };
    this._fallback = null;
    this._levelBuf = null;
  }

  get supported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia &&
              (window.AudioContext || window.webkitAudioContext));
  }

  // マイクを開いて処理チェーンを構築（ユーザー操作から呼ぶこと：iOS必須）
  async start() {
    if (this.running) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC({ latencyHint: "interactive" });
    if (this.ctx.state === "suspended") await this.ctx.resume();

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1
      },
      video: false
    });

    this.srcNode = this.ctx.createMediaStreamSource(this.stream);

    // --- 前段：ハイパス（低域のモゴモゴがグレインを濁すのを防ぐ） ---
    this.hp = this.ctx.createBiquadFilter();
    this.hp.type = "highpass";
    this.hp.frequency.value = 85;
    this.hp.Q.value = 0.7;

    // --- ピッチシフター本体 ---
    try {
      const blob = new Blob([WORKLET_SRC], { type: "application/javascript" });
      const url = URL.createObjectURL(blob);
      await this.ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      this.node = new AudioWorkletNode(this.ctx, "pitch-processor", {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1]
      });
      this.useWorklet = true;
    } catch (e) {
      this.node = this._buildFallback();   // AudioWorklet 非対応 → ScriptProcessor
      this.useWorklet = false;
    }

    // --- ロボ風（振幅変調：90Hzサイン波でダーレク系の響き） ---
    this.ringMod = this.ctx.createOscillator();
    this.ringMod.type = "sine";
    this.ringMod.frequency.value = 90;
    this.ringGain = this.ctx.createGain();
    this.ringGain.gain.value = 0;            // robot=0 のとき無効
    this.ringMod.connect(this.ringGain.gain);
    this.ringMod.start();
    const ringPath = this.ctx.createGain();
    ringPath.gain.value = 1;

    // --- 太さEQ（＋で太く低域寄り、−で細く明るく） ---
    this.loShelf = this.ctx.createBiquadFilter();
    this.loShelf.type = "lowshelf";
    this.loShelf.frequency.value = 200;
    this.loShelf.gain.value = 0;
    this.hiShelf = this.ctx.createBiquadFilter();
    this.hiShelf.type = "highshelf";
    this.hiShelf.frequency.value = 4500;
    this.hiShelf.gain.value = 0;

    // --- コンプ＋メイクアップ（配信で聞き取りやすい音圧に） ---
    this.comp = this.ctx.createDynamicsCompressor();
    this.comp.threshold.value = -22;
    this.comp.knee.value = 12;
    this.comp.ratio.value = 3;
    this.comp.attack.value = 0.005;
    this.comp.release.value = 0.15;
    this.makeup = this.ctx.createGain();
    this.makeup.gain.value = 1.2;

    // --- 出力段 ---
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 512;
    this._levelBuf = new Uint8Array(this.analyser.frequencyBinCount);
    this.dest = this.ctx.createMediaStreamDestination();
    this.monitorGain = this.ctx.createGain();
    this.monitorGain.gain.value = 0;         // 既定モニターOFF（ハウリング防止）

    // 接続：
    // mic → hp → pitch → (ringGain / 直通) → loShelf → hiShelf → comp → makeup
    //   → analyser → dest / monitor
    this.srcNode.connect(this.hp);
    this.hp.connect(this.node);
    this.node.connect(this.ringGain);        // ringGain.gain が変調される
    this.ringGain.connect(ringPath);
    this.node.connect(ringPath);             // 素通り経路（robot=0 のとき主役）
    ringPath.connect(this.loShelf);
    this.loShelf.connect(this.hiShelf);
    this.hiShelf.connect(this.comp);
    this.comp.connect(this.makeup);
    this.makeup.connect(this.analyser);
    this.analyser.connect(this.dest);
    this.analyser.connect(this.monitorGain);
    this.monitorGain.connect(this.ctx.destination);

    this.outStream = this.dest.stream;
    this.running = true;
    this.applyParams();
  }

  // ScriptProcessor フォールバック（古いSafari等）※ワークレットと同一アルゴリズム
  _buildFallback() {
    const sp = this.ctx.createScriptProcessor(2048, 1, 1);
    const st = {
      size: 32768,
      buf: new Float32Array(32768),
      w: 0,
      phase: 0,
      grain: Math.round(this.ctx.sampleRate * 0.05),
      minLag: 64
    };
    this._fallback = st;

    const readLerp = (pos) => {
      let p = pos % st.size;
      if (p < 0) p += st.size;
      const i0 = p | 0, i1 = (i0 + 1) % st.size, f = p - i0;
      return st.buf[i0] + (st.buf[i1] - st.buf[i0]) * f;
    };

    sp.onaudioprocess = (ev) => {
      const inp = ev.inputBuffer.getChannelData(0);
      const out = ev.outputBuffer.getChannelData(0);
      const speed = this.params.pitch;
      const wet = this.params.wet;
      const g = st.grain;
      const inc = (1 - speed) / g;

      for (let i = 0; i < inp.length; i++) {
        st.buf[st.w] = inp[i];
        st.w = (st.w + 1) % st.size;
        st.phase += inc;
        st.phase -= Math.floor(st.phase);
        const p1 = st.phase, p2 = (st.phase + 0.5) % 1;
        const w1 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p1);
        const w2 = 1 - w1;
        const d1 = st.minLag + p1 * g;
        const d2 = st.minLag + p2 * g;
        const s = readLerp(st.w - 1 - d1) * w1 + readLerp(st.w - 1 - d2) * w2;
        const y = s * wet + inp[i] * (1 - wet);
        out[i] = Math.tanh(y * 1.15) * 0.95;
      }
    };
    return sp;
  }

  // パラメータ反映
  setParams(p) {
    Object.assign(this.params, p);
    this.applyParams();
  }

  applyParams() {
    if (!this.running) return;
    const { pitch, tone, robot, wet } = this.params;
    const t = this.ctx.currentTime;
    if (this.useWorklet && this.node.parameters) {
      this.node.parameters.get("pitch").setTargetAtTime(pitch, t, 0.02);
      this.node.parameters.get("wet").setTargetAtTime(wet, t, 0.02);
    }
    // 太さ：+で低域ブースト＆高域カット、−で逆
    if (this.loShelf) this.loShelf.gain.setTargetAtTime(tone * 6, t, 0.05);
    if (this.hiShelf) this.hiShelf.gain.setTargetAtTime(-tone * 4, t, 0.05);
    if (this.ringGain) this.ringGain.gain.setTargetAtTime(robot ? 0.85 : 0, t, 0.05);
  }

  applyPreset(key) {
    const p = VOICE_PRESETS[key];
    if (!p) return;
    this.setParams({ pitch: p.pitch, tone: p.tone, robot: p.robot, wet: p.wet });
  }

  // モニター（自分の声を聞く）ON/OFF ※イヤホン必須
  setMonitor(on) {
    if (!this.monitorGain) return;
    this.monitorGain.gain.setTargetAtTime(on ? 0.85 : 0, this.ctx.currentTime, 0.03);
  }

  // 入力レベル 0..1（UIメーター用）
  getLevel() {
    if (!this.analyser || !this._levelBuf) return 0;
    this.analyser.getByteTimeDomainData(this._levelBuf);
    let peak = 0;
    for (let i = 0; i < this._levelBuf.length; i++) {
      const v = Math.abs(this._levelBuf[i] - 128) / 128;
      if (v > peak) peak = v;
    }
    return Math.min(1, peak * 1.6);
  }

  async stop() {
    this.running = false;
    try { if (this.ringMod) this.ringMod.stop(); } catch (e) {}
    try { if (this.node) this.node.disconnect(); } catch (e) {}
    try { if (this.srcNode) this.srcNode.disconnect(); } catch (e) {}
    if (this.stream) this.stream.getTracks().forEach((tr) => tr.stop());
    if (this.ctx) { try { await this.ctx.close(); } catch (e) {} }
    this.ctx = null; this.node = null; this.srcNode = null;
    this.stream = null; this.outStream = null; this.analyser = null;
    this.hp = null; this.loShelf = null; this.hiShelf = null;
    this.comp = null; this.makeup = null;
    this.ringMod = null; this.ringGain = null;
  }
}
