// ============================================================
// STUDIO J V-CAM — voice.js  v1.1.0
// ボイスチェンジャー（Web Audio API）
//   マイク入力 → ピッチシフト＋フォルマントシフト → 出力
// 音声はすべて端末内で処理。外部送信・録画なし。
// ============================================================
//
// 【設計メモ】
//  ・ピッチだけ変えても「声質（フォルマント）」が残るので声バレしやすい。
//    そこで granular pitch shift（時間軸）＋ resample formant shift（周波数軸）
//    を独立に掛けて、別人の声にする。
//  ・AudioWorklet を第一候補、非対応環境は ScriptProcessor にフォールバック。
//  ・ハウリング防止のため、既定では出力をスピーカーへ流さない（モニターOFF）。
//    配信ソフトへは MediaStreamDestination の stream を渡す。

// ---- AudioWorklet のソース（Blob URL で読み込むので単一ファイル配布のまま）----
const WORKLET_SRC = `
class PitchProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      { name: 'pitch',   defaultValue: 1.0, minValue: 0.4, maxValue: 2.5, automationRate: 'k-rate' },
      { name: 'formant', defaultValue: 1.0, minValue: 0.5, maxValue: 2.0, automationRate: 'k-rate' },
      { name: 'wet',     defaultValue: 1.0, minValue: 0.0, maxValue: 1.0, automationRate: 'k-rate' }
    ];
  }

  constructor() {
    super();
    // リングバッファ（約 200ms）
    this.size = 8192;
    this.buf = new Float32Array(this.size);
    this.writePos = 0;
    // 2つの読み出しヘッドをクロスフェードさせて、ピッチ変更時のプチプチ音を消す
    this.grain = 2048;               // グレイン長（サンプル）
    this.head = 0;                   // 読み出し位置（float）
    this.phase = 0;                  // グレイン内位相 0..1
    this.ready = false;
  }

  process(inputs, outputs, params) {
    const input = inputs[0];
    const output = outputs[0];
    if (!output || output.length === 0) return true;

    const inCh = (input && input.length > 0) ? input[0] : null;
    const outCh = output[0];
    const n = outCh.length;

    const pitch = params.pitch[0];
    const formant = params.formant[0];
    const wet = params.wet[0];

    // 入力をリングバッファへ書き込み
    if (inCh) {
      for (let i = 0; i < n; i++) {
        this.buf[this.writePos] = inCh[i];
        this.writePos = (this.writePos + 1) % this.size;
      }
      this.ready = true;
    } else {
      for (let i = 0; i < n; i++) outCh[i] = 0;
      return true;
    }

    // ピッチ比 = pitch * formant にすると、リサンプルで声道長も一緒に伸縮する。
    // grain の進み方（rate）で時間軸を戻すことで、
    // 「話速そのまま・ピッチとフォルマントは別々」を実現する。
    const speed = pitch * formant;
    const grain = this.grain;
    const half = grain * 0.5;

    // 書き込みヘッドから安全な距離（グレイン1個分）だけ後ろを読む
    const safeLag = grain + 256;

    for (let i = 0; i < n; i++) {
      // 2ヘッドのオフセット（半グレインずらし）
      const p1 = this.phase;
      const p2 = (this.phase + 0.5) % 1.0;

      // Hann 窓でクロスフェード
      const w1 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p1);
      const w2 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p2);

      const base = this.writePos - safeLag;
      const r1 = base + this.head + p1 * grain;
      const r2 = base + this.head + p2 * grain;

      const s1 = this.readLerp(r1);
      const s2 = this.readLerp(r2);

      let y = (s1 * w1 + s2 * w2) / Math.max(0.0001, (w1 + w2));

      // ドライ音（原音）とのミックス
      const dry = inCh[i];
      y = y * wet + dry * (1 - wet);

      // 軽いソフトクリップ（音割れ防止）
      outCh[i] = Math.tanh(y * 1.2) * 0.92;

      // グレイン位相を進める
      this.phase += (speed - 1) / grain + 1 / grain;
      if (this.phase >= 1) this.phase -= 1;
      if (this.phase < 0) this.phase += 1;
    }

    // 2ch 以降は同じものをコピー（モノラル前提）
    for (let ch = 1; ch < output.length; ch++) {
      output[ch].set(outCh);
    }
    return true;
  }

  // 線形補間つき読み出し（ラップアラウンド対応）
  readLerp(pos) {
    let p = pos % this.size;
    if (p < 0) p += this.size;
    const i0 = Math.floor(p);
    const i1 = (i0 + 1) % this.size;
    const f = p - i0;
    return this.buf[i0] * (1 - f) + this.buf[i1] * f;
  }
}
registerProcessor('pitch-processor', PitchProcessor);
`;

// ---- プリセット ----
// pitch: 声の高さ / formant: 声質（声道の太さ）/ 低いほど太く低い
export const VOICE_PRESETS = {
  off:      { label: "🎤 素の声",      pitch: 1.00, formant: 1.00, robot: 0, wet: 0.0 },
  lowman:   { label: "🕶️ 低音イケメン", pitch: 0.78, formant: 0.86, robot: 0, wet: 1.0 },
  deep:     { label: "🌑 超低音",       pitch: 0.62, formant: 0.78, robot: 0, wet: 1.0 },
  high:     { label: "✨ 高め",         pitch: 1.28, formant: 1.14, robot: 0, wet: 1.0 },
  anime:    { label: "🎀 アニメ声",     pitch: 1.52, formant: 1.30, robot: 0, wet: 1.0 },
  robot:    { label: "🤖 ロボ風",       pitch: 1.00, formant: 0.94, robot: 1, wet: 1.0 },
  alien:    { label: "👾 エイリアン",   pitch: 0.88, formant: 1.42, robot: 1, wet: 1.0 }
};

export class VoiceChanger {
  constructor() {
    this.ctx = null;
    this.srcNode = null;
    this.stream = null;       // マイクの生ストリーム
    this.outStream = null;    // 加工後のストリーム（配信ソフトへ渡す用）
    this.node = null;         // AudioWorkletNode または ScriptProcessorNode
    this.useWorklet = false;
    this.dest = null;
    this.monitorGain = null;
    this.analyser = null;
    this.ringMod = null;      // ロボ風用
    this.ringGain = null;
    this.dryGain = null;
    this.wetGain = null;
    this.running = false;
    this.params = { pitch: 1.0, formant: 1.0, robot: 0, wet: 1.0 };
    this._fallback = null;    // ScriptProcessor 用の状態
    this._levelBuf = null;
  }

  get supported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia &&
              (window.AudioContext || window.webkitAudioContext));
  }

  // マイクを開いて処理チェーンを構築する（ユーザー操作から呼ぶこと：iOS必須）
  async start() {
    if (this.running) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC({ latencyHint: "interactive" });
    if (this.ctx.state === "suspended") await this.ctx.resume();

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1
      },
      video: false
    });

    this.srcNode = this.ctx.createMediaStreamSource(this.stream);

    // --- ピッチシフター本体 ---
    try {
      const blob = new Blob([WORKLET_SRC], { type: "application/javascript" });
      const url = URL.createObjectURL(blob);
      await this.ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      this.node = new AudioWorkletNode(this.ctx, "pitch-processor", {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        outputChannelCount: [1]
      });
      this.useWorklet = true;
    } catch (e) {
      // AudioWorklet 非対応 → ScriptProcessor で代替
      this.node = this._buildFallback();
      this.useWorklet = false;
    }

    // --- ロボ風（リングモジュレーター）---
    this.ringMod = this.ctx.createOscillator();
    this.ringMod.type = "square";
    this.ringMod.frequency.value = 62;          // 低めの矩形波でメカっぽく
    this.ringGain = this.ctx.createGain();
    this.ringGain.gain.value = 0;               // robot=0 のとき無効
    this.ringMod.connect(this.ringGain.gain);
    this.ringMod.start();

    const ringPath = this.ctx.createGain();
    ringPath.gain.value = 1;

    // --- 出力段 ---
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 512;
    this._levelBuf = new Uint8Array(this.analyser.frequencyBinCount);

    this.dest = this.ctx.createMediaStreamDestination();
    this.monitorGain = this.ctx.createGain();
    this.monitorGain.gain.value = 0;            // 既定はモニターOFF（ハウリング防止）

    // 接続： mic → pitch → [ringmod] → analyser → dest / monitor
    this.srcNode.connect(this.node);
    this.node.connect(this.ringGain);           // ringGain.gain が振幅変調される
    this.ringGain.connect(ringPath);
    this.node.connect(ringPath);                // 素通り経路（robot=0 のとき主役）
    ringPath.connect(this.analyser);
    this.analyser.connect(this.dest);
    this.analyser.connect(this.monitorGain);
    this.monitorGain.connect(this.ctx.destination);

    this.outStream = this.dest.stream;
    this.running = true;
    this.applyParams();
  }

  // ScriptProcessor フォールバック（古いSafari等）
  _buildFallback() {
    const N = 4096;
    const sp = this.ctx.createScriptProcessor(N, 1, 1);
    const size = 8192, grain = 2048;
    const st = { buf: new Float32Array(size), w: 0, phase: 0, size, grain };
    this._fallback = st;

    const readLerp = (pos) => {
      let p = pos % st.size;
      if (p < 0) p += st.size;
      const i0 = Math.floor(p), i1 = (i0 + 1) % st.size, f = p - i0;
      return st.buf[i0] * (1 - f) + st.buf[i1] * f;
    };

    sp.onaudioprocess = (ev) => {
      const inp = ev.inputBuffer.getChannelData(0);
      const out = ev.outputBuffer.getChannelData(0);
      const speed = this.params.pitch * this.params.formant;
      const wet = this.params.wet;
      const g = st.grain, safeLag = g + 256;

      for (let i = 0; i < inp.length; i++) {
        st.buf[st.w] = inp[i];
        st.w = (st.w + 1) % st.size;
      }
      for (let i = 0; i < out.length; i++) {
        const p1 = st.phase, p2 = (st.phase + 0.5) % 1;
        const w1 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p1);
        const w2 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p2);
        const base = st.w - safeLag - (out.length - i);
        const s1 = readLerp(base + p1 * g);
        const s2 = readLerp(base + p2 * g);
        let y = (s1 * w1 + s2 * w2) / Math.max(0.0001, w1 + w2);
        y = y * wet + inp[i] * (1 - wet);
        out[i] = Math.tanh(y * 1.2) * 0.92;
        st.phase += speed / g;
        if (st.phase >= 1) st.phase -= 1;
        if (st.phase < 0) st.phase += 1;
      }
    };
    return sp;
  }

  // パラメータを反映
  setParams(p) {
    Object.assign(this.params, p);
    this.applyParams();
  }

  applyParams() {
    if (!this.running) return;
    const { pitch, formant, robot, wet } = this.params;
    if (this.useWorklet && this.node.parameters) {
      const t = this.ctx.currentTime;
      this.node.parameters.get("pitch").setTargetAtTime(pitch, t, 0.02);
      this.node.parameters.get("formant").setTargetAtTime(formant, t, 0.02);
      this.node.parameters.get("wet").setTargetAtTime(wet, t, 0.02);
    }
    if (this.ringGain) {
      this.ringGain.gain.setTargetAtTime(robot ? 0.85 : 0, this.ctx.currentTime, 0.05);
    }
  }

  applyPreset(key) {
    const p = VOICE_PRESETS[key];
    if (!p) return;
    this.setParams({ pitch: p.pitch, formant: p.formant, robot: p.robot, wet: p.wet });
  }

  // モニター（自分の声を聞く）ON/OFF ※イヤホン必須
  setMonitor(on) {
    if (!this.monitorGain) return;
    this.monitorGain.gain.setTargetAtTime(on ? 0.85 : 0, this.ctx.currentTime, 0.03);
  }

  // 入力レベル 0..1（UIメーター用）
  getLevel() {
    if (!this.analyser || !this._levelBuf) return 0;
    this.analyser.getByteTimeDomainData(this._levelBuf);
    let peak = 0;
    for (let i = 0; i < this._levelBuf.length; i++) {
      const v = Math.abs(this._levelBuf[i] - 128) / 128;
      if (v > peak) peak = v;
    }
    return Math.min(1, peak * 1.6);
  }

  async stop() {
    this.running = false;
    try { if (this.ringMod) this.ringMod.stop(); } catch (e) {}
    try { if (this.node) this.node.disconnect(); } catch (e) {}
    try { if (this.srcNode) this.srcNode.disconnect(); } catch (e) {}
    if (this.stream) this.stream.getTracks().forEach((t) => t.stop());
    if (this.ctx) { try { await this.ctx.close(); } catch (e) {} }
    this.ctx = null; this.node = null; this.srcNode = null;
    this.stream = null; this.outStream = null; this.analyser = null;
  }
}
