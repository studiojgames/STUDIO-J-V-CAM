// ============================================================
// STUDIO J V-CAM v1.0.0
// 顔バレ防止フィルターカメラ（盛れモード / アバターモード）
// 映像はすべて端末内で処理。外部送信・録画なし。
// ============================================================

import { FaceLandmarker, FilesetResolver } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
import { VoiceChanger, VOICE_PRESETS } from "./voice.js?v=20260723b";

const MP_WASM  = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const MP_MODEL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const VERSION  = "1.2.0";

// ---- ランドマーク定義（MediaPipe FaceMesh 478点） ----
const FACE_OVAL = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109];
const JAW = FACE_OVAL.slice(FACE_OVAL.indexOf(454), FACE_OVAL.indexOf(234) + 1);
const EYE_R = { outer: 33,  inner: 133, top: 159, bottom: 145, iris: 468 }; // 画面向かって左側の目
const EYE_L = { outer: 263, inner: 362, top: 386, bottom: 374, iris: 473 }; // 画面向かって右側の目
const MOUTH = { left: 61, right: 291, top: 13, bottom: 14 };
const NOSE_TIP = 1;

// ---- カラーテーマ ----
const COLORS = {
  pink:   { main: "#ff3d8d", glow: "rgba(255,61,141,0.85)", sub: "#ff9ec9" },
  cyan:   { main: "#22e6ff", glow: "rgba(34,230,255,0.85)",  sub: "#9ef4ff" },
  purple: { main: "#a86bff", glow: "rgba(168,107,255,0.85)", sub: "#d3b4ff" },
  gold:   { main: "#ffc93d", glow: "rgba(255,201,61,0.80)",  sub: "#ffe49e" }
};

// ---- 状態 ----
const state = {
  mode: "A",        // "A"=盛れ / "B"=アバター
  color: "pink",
  barOn: true,
  mirror: true,
  bihada: 60,
  running: false,
  lastFaceTime: 0,  // 最後に顔を検出した時刻
  faceOK: false,
  voiceOn: false,   // ボイチェン稼働中か
  voicePreset: "lowman"
};

// ---- DOM ----
const $ = (id) => document.getElementById(id);
const video = $("cam");
const cv = $("view");
const ctx = cv.getContext("2d");

// オフスクリーン（ぼかし用・目の拡大用）
const blurC = document.createElement("canvas");
const blurCtx = blurC.getContext("2d");
const eyeC = document.createElement("canvas");
const eyeCtx = eyeC.getContext("2d");

let landmarker = null;
let lastVideoTime = -1;
let lastResult = null;
let lastLm = null;      // 直近のランドマーク（短時間ロスト時のバー維持用）
let fps = 0, fpsFrames = 0, fpsTime = 0;
let uiTimer = 0, uiVisible = true;


// ============================================================
// 初期化
// ============================================================
async function initLandmarker() {
  const fileset = await FilesetResolver.forVisionTasks(MP_WASM);
  landmarker = await FaceLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MP_MODEL, delegate: "GPU" },
    runningMode: "VIDEO",
    numFaces: 1,
    outputFaceBlendshapes: true,
    outputFacialTransformationMatrixes: false
  });
}

async function startCamera() {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: false
  });
  video.srcObject = stream;
  await video.play();
  cv.width = video.videoWidth || 1280;
  cv.height = video.videoHeight || 720;
}

function showError(err) {
  const el = $("errMsg");
  let msg = "";
  if (err && err.name === "NotAllowedError") {
    msg = "カメラの使用がブロックされています。ブラウザのサイト設定でカメラを「許可」にしてから、再読み込みしてください。";
  } else if (err && err.name === "NotFoundError") {
    msg = "カメラが見つかりませんでした。カメラ付きの端末で開くか、接続を確認してください。";
  } else if (err && err.name === "NotReadableError") {
    msg = "カメラを他のアプリが使用中の可能性があります。他のアプリを閉じてから再読み込みしてください。";
  } else {
    msg = "エラー: " + (err && err.message ? err.message : String(err));
  }
  el.textContent = msg;
  $("hudError").classList.remove("hidden");
}

// ============================================================
// メインループ
// ============================================================
function loop(ts) {
  if (!state.running) return;
  if (video.readyState >= 2) {
    if (video.currentTime !== lastVideoTime) {
      lastVideoTime = video.currentTime;
      try {
        lastResult = landmarker.detectForVideo(video, performance.now());
      } catch (e) { /* 一時的な検出エラーは無視 */ }
    }
    render(lastResult, ts);
  }
  updateFps(ts);
  requestAnimationFrame(loop);
}

function updateFps(ts) {
  fpsFrames++;
  if (ts - fpsTime > 500) {
    fps = Math.round(fpsFrames * 1000 / (ts - fpsTime));
    fpsFrames = 0;
    fpsTime = ts;
  }
}

function readBlend(result) {
  const map = {};
  if (result && result.faceBlendshapes && result.faceBlendshapes[0]) {
    for (const c of result.faceBlendshapes[0].categories) map[c.categoryName] = c.score;
  }
  return map;
}

function render(result, ts) {
  const W = cv.width, H = cv.height;
  const lm = result && result.faceLandmarks && result.faceLandmarks[0] ? result.faceLandmarks[0] : null;
  const bs = readBlend(result);
  const now = performance.now();
  if (lm) { state.lastFaceTime = now; lastLm = lm; }
  state.faceOK = (now - state.lastFaceTime) < 400;

  if (state.mode === "A") {
    ctx.save();
    if (state.mirror) { ctx.translate(W, 0); ctx.scale(-1, 1); }
    renderModeA(lm, W, H);
    ctx.restore();
  } else {
    // モードBはアバター絵なのでミラーしない（首振りの符号だけ内部で調整）
    renderModeB(lm, bs, W, H, ts);
  }

  drawLogo(W, H);
  drawStatus(W, H);
}

// ============================================================
// モードA：盛れモード（美肌・小顔シェード・目デカ・ネオンバー）
// ============================================================
function renderModeA(lm, W, H) {
  ctx.drawImage(video, 0, 0, W, H);

  // 追跡できていない間は必ず全面ブラー（顔バレ事故防止・フェイルセーフ）
  const useLm = lm || (state.faceOK ? lastLm : null);
  if (!useLm) {
    privacyBlur(W, H);
    return;
  }

  // --- 美肌：顔領域にソフトブラーを重ねる ---
  const alpha = (state.bihada / 100) * 0.85;
  if (alpha > 0.02) {
    const b = makeBlur(10);
    ctx.save();
    ctx.clip(faceOvalPath(useLm, W, H));
    ctx.globalAlpha = alpha;
    ctx.drawImage(b, 0, 0, W, H);
    ctx.globalAlpha = 1;
    ctx.restore();

    // 目と口はシャープに戻す（ぼやけ防止）
    sharpMouth(useLm, W, H);
    if (!state.barOn) {
      sharpEye(EYE_R, useLm, W, H);
      sharpEye(EYE_L, useLm, W, H);
    }
  }

  // --- 小顔シェーディング（輪郭に沿った柔らかい影） ---
  jawShade(useLm, W, H);

  // --- 目デカ（バーOFF時のみ） ---
  if (!state.barOn) {
    magnifyEye(EYE_R, useLm, W, H);
    magnifyEye(EYE_L, useLm, W, H);
  }

  // --- トーンアップ（血色・透明感） ---
  ctx.save();
  ctx.globalCompositeOperation = "soft-light";
  ctx.fillStyle = "rgba(255,214,222,0.30)";
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = "screen";
  ctx.fillStyle = "rgba(255,240,250,0.05)";
  ctx.fillRect(0, 0, W, H);
  ctx.restore();

  // --- 目元ネオンバー ---
  if (state.barOn) neonBar(useLm, W, H);
}

function faceOvalPath(lm, W, H) {
  const p = new Path2D();
  for (let i = 0; i < FACE_OVAL.length; i++) {
    const pt = lm[FACE_OVAL[i]];
    const x = pt.x * W, y = pt.y * H;
    if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
  }
  p.closePath();
  return p;
}

// 縮小→拡大で作る軽量ブラー（Safari含む全ブラウザ対応）
function makeBlur(divisor) {
  const bw = Math.max(8, Math.round(cv.width / divisor));
  const bh = Math.max(8, Math.round(cv.height / divisor));
  blurC.width = bw; blurC.height = bh;
  blurCtx.drawImage(video, 0, 0, bw, bh);
  return blurC;
}

function privacyBlur(W, H) {
  const bw = 24, bh = Math.max(2, Math.round(bw * H / W));
  blurC.width = bw; blurC.height = bh;
  blurCtx.drawImage(video, 0, 0, bw, bh);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(blurC, 0, 0, W, H);
  ctx.fillStyle = "rgba(8,8,16,0.35)";
  ctx.fillRect(0, 0, W, H);
}

function sharpEye(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner], t = lm[eye.top], b = lm[eye.bottom];
  const cx = (o.x + i2.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const rw = Math.hypot((o.x - i2.x) * W, (o.y - i2.y) * H) * 0.85;
  const rh = Math.max(8, Math.abs(b.y - t.y) * H * 1.8);
  sharpRegion(cx, cy, rw, rh, W, H);
}

function sharpMouth(lm, W, H) {
  const l = lm[MOUTH.left], r = lm[MOUTH.right], t = lm[MOUTH.top], b = lm[MOUTH.bottom];
  const cx = (l.x + r.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const mw = Math.hypot((r.x - l.x) * W, (r.y - l.y) * H);
  sharpRegion(cx, cy, mw * 0.78, mw * 0.5, W, H);
}

function sharpRegion(cx, cy, rw, rh, W, H) {
  ctx.save();
  const p = new Path2D();
  p.ellipse(cx, cy, rw, rh, 0, 0, Math.PI * 2);
  ctx.clip(p);
  ctx.globalAlpha = 0.9;
  ctx.drawImage(video, 0, 0, W, H);
  ctx.globalAlpha = 1;
  ctx.restore();
}

function jawShade(lm, W, H) {
  const a = lm[234], b = lm[454];
  const fw = Math.hypot((b.x - a.x) * W, (b.y - a.y) * H);
  const p = new Path2D();
  for (let i = 0; i < JAW.length; i++) {
    const pt = lm[JAW[i]];
    const x = pt.x * W, y = pt.y * H;
    if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
  }
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "rgba(70,35,30,0.10)";
  ctx.lineWidth = fw * 0.10;
  ctx.shadowColor = "rgba(70,35,30,0.32)";
  ctx.shadowBlur = fw * 0.08;
  ctx.stroke(p);
  ctx.restore();
}

function magnifyEye(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner], t = lm[eye.top], b = lm[eye.bottom];
  const cx = (o.x + i2.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const ew = Math.hypot((o.x - i2.x) * W, (o.y - i2.y) * H) * 1.9;
  const eh = Math.max(12, Math.abs(b.y - t.y) * H * 3.2);
  const k = 1.12; // 拡大率（控えめ）
  const sw = ew, sh = eh, dw = ew * k, dh = eh * k;
  const sx = cx - sw / 2, sy = cy - sh / 2;
  const dx = cx - dw / 2, dy = cy - dh / 2;

  eyeC.width = Math.max(2, Math.ceil(dw));
  eyeC.height = Math.max(2, Math.ceil(dh));
  eyeCtx.clearRect(0, 0, eyeC.width, eyeC.height);
  eyeCtx.drawImage(video, sx, sy, sw, sh, 0, 0, dw, dh);
  // 縁を柔らかくフェード
  const g = eyeCtx.createRadialGradient(dw / 2, dh / 2, Math.min(dw, dh) * 0.25, dw / 2, dh / 2, Math.min(dw, dh) * 0.52);
  g.addColorStop(0, "rgba(0,0,0,1)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  eyeCtx.globalCompositeOperation = "destination-in";
  eyeCtx.fillStyle = g;
  eyeCtx.fillRect(0, 0, eyeC.width, eyeC.height);
  eyeCtx.globalCompositeOperation = "source-over";
  ctx.drawImage(eyeC, dx, dy);
}

function eyeCenterPx(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner];
  return { x: (o.x + i2.x) / 2 * W, y: (o.y + i2.y) / 2 * H };
}

function roundRectPath(x, y, w, h, r) {
  const p = new Path2D();
  p.moveTo(x + r, y);
  p.lineTo(x + w - r, y);
  p.arcTo(x + w, y, x + w, y + r, r);
  p.lineTo(x + w, y + h - r);
  p.arcTo(x + w, y + h, x + w - r, y + h, r);
  p.lineTo(x + r, y + h);
  p.arcTo(x, y + h, x, y + h - r, r);
  p.lineTo(x, y + r);
  p.arcTo(x, y, x + r, y, r);
  p.closePath();
  return p;
}

function neonBar(lm, W, H) {
  const c = COLORS[state.color];
  const e1 = eyeCenterPx(EYE_R, lm, W, H);
  const e2 = eyeCenterPx(EYE_L, lm, W, H);
  const cx = (e1.x + e2.x) / 2, cy = (e1.y + e2.y) / 2;
  const d = Math.hypot(e2.x - e1.x, e2.y - e1.y);
  const ang = Math.atan2(e2.y - e1.y, e2.x - e1.x);
  const bw = d * 2.35;
  const bh = Math.max(18, d * 0.62);
  const r = bh * 0.35;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(ang);
  const p = roundRectPath(-bw / 2, -bh / 2, bw, bh, r);

  // 本体（黒ガラス）＋外側グロー
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = bh * 0.9;
  ctx.fillStyle = "rgba(10,10,18,0.93)";
  ctx.fill(p);
  ctx.shadowBlur = 0;

  // ガラスの光沢
  const g = ctx.createLinearGradient(0, -bh / 2, 0, bh / 2);
  g.addColorStop(0, "rgba(255,255,255,0.10)");
  g.addColorStop(0.5, "rgba(255,255,255,0.02)");
  g.addColorStop(1, "rgba(255,255,255,0.10)");
  ctx.fillStyle = g;
  ctx.fill(p);

  // ネオン縁取り
  ctx.lineWidth = Math.max(2, bh * 0.08);
  ctx.strokeStyle = c.main;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = bh * 0.6;
  ctx.stroke(p);

  // センターのスキャンライン
  ctx.shadowBlur = 0;
  ctx.strokeStyle = c.sub;
  ctx.globalAlpha = 0.5;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-bw / 2 + r, 0);
  ctx.lineTo(bw / 2 - r, 0);
  ctx.stroke();
  ctx.restore();
}

// ============================================================
// モードB：アニメアバターVTuber（7パーツ レイヤー合成方式）
// 背景・体・顔(4表情)を重ね、顔だけをトラッキングで動かす
// ============================================================

// パーツ画像の読み込み
const PARTS = {
  bg:    { src: "avatar_bg.jpg?v=20260723b",       img: new Image(), ok: false },
  body:  { src: "avatar_body.png?v=20260723b",     img: new Image(), ok: false },
  eo_mc: { src: "avatar_face_eo_mc.png?v=20260723b", img: new Image(), ok: false }, // 目開き口閉じ
  ec_mc: { src: "avatar_face_ec_mc.png?v=20260723b", img: new Image(), ok: false }, // 目閉じ口閉じ
  eo_mo: { src: "avatar_face_eo_mo.png?v=20260723b", img: new Image(), ok: false }, // 目開き口開き
  ec_mo: { src: "avatar_face_ec_mo.png?v=20260723b", img: new Image(), ok: false }, // 目閉じ口開き
  smile: { src: "avatar_face_smile.png?v=20260723b", img: new Image(), ok: false }  // 笑顔
};
let partsLoaded = 0, partsTotal = Object.keys(PARTS).length;
for (const k in PARTS) {
  PARTS[k].img.onload = () => { PARTS[k].ok = true; partsLoaded++; };
  PARTS[k].img.onerror = () => { partsLoaded++; };
  PARTS[k].img.src = PARTS[k].src;
}
function partsReady() { return PARTS.bg.ok && PARTS.eo_mc.ok; }

// 顔レイヤーの位置微調整（スライダー対応）
const RIG = {
  faceX: 0.0,    // 顔の横オフセット（画面幅比）
  faceY: 0.0,    // 顔の縦オフセット
  scale: 1.00,   // 全体スケール
  blinkThresh: 0.5,  // まばたき判定しきい値
  mouthThresh: 0.22, // 口開き判定しきい値
  smileThresh: 0.25  // 笑顔判定しきい値
};

// 駆動値（スムージング付き）
function newDriver() {
  return { roll: 0, yaw: 0, pitch: 0, blink: 0, mouth: 0, smile: 0, breath: 0, x: 0, y: 0 };
}
const AV = { cur: newDriver(), target: newDriver() };

// 背景パーティクル
const particles = [];
for (let i = 0; i < 30; i++) {
  particles.push({
    x: Math.random(), y: Math.random(),
    r: Math.random() * 1.8 + 0.5,
    sp: Math.random() * 0.0009 + 0.0003,
    tw: Math.random() * Math.PI * 2
  });
}

function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }

function eyeCenterN(eye, lm) {
  const o = lm[eye.outer], i2 = lm[eye.inner];
  return { x: (o.x + i2.x) / 2, y: (o.y + i2.y) / 2 };
}

let rigAdjust = false;

function renderModeB(lm, bs, W, H, ts) {
  const c = COLORS[state.color];

  // 読み込み中
  if (!partsReady()) {
    ctx.fillStyle = "#05060f";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "rgba(220,225,255,0.85)";
    ctx.font = "600 " + Math.round(H * 0.03) + "px 'Hiragino Sans', sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText("アバター読み込み中… " + partsLoaded + "/" + partsTotal, W / 2, H / 2);
    return;
  }

  updateAvatar(lm, bs, ts);

  // --- レイヤー計算（縦長パーツを画面にフィット：高さ基準でカバー） ---
  const bgImg = PARTS.bg.img;
  const iw = bgImg.width, ih = bgImg.height;
  const scale = Math.max(W / iw, H / ih);
  const dw = iw * scale, dh = ih * scale;
  const dx = (W - dw) / 2;
  const dy = (H - dh) / 2;

  // 1) 背景（固定）
  ctx.drawImage(bgImg, dx, dy, dw, dh);

  // ネオングロー＆パーティクル（背景の上）
  const rg = ctx.createRadialGradient(W / 2, H * 0.4, 10, W / 2, H * 0.4, H * 0.6);
  rg.addColorStop(0, c.glow.replace(/0\.\d+/, "0.10"));
  rg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = rg;
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  for (const pt of particles) {
    pt.y -= pt.sp;
    if (pt.y < -0.05) { pt.y = 1.05; pt.x = Math.random(); }
    ctx.globalAlpha = 0.25 + 0.25 * Math.sin(ts / 800 + pt.tw);
    ctx.fillStyle = c.sub;
    ctx.beginPath();
    ctx.arc(pt.x * W, pt.y * H, pt.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  const s = AV.cur;

  // 2)+3) 体と顔を「同じ変換」でまとめて動かす（首が外れないように一体化）
  const breatheY = (s.breath - 0.5) * H * 0.006;
  const faceImg = pickFace(s);

  ctx.save();
  // 回転軸はキャラの下の方（肩〜胸＝上から約65%）に置く。
  // ここを軸にすると、頭が振り子のように自然に揺れ、体もついてくる。
  const pivotX = dx + dw * 0.5 + RIG.faceX * W;
  const pivotY = dy + dh * 0.65;
  ctx.translate(pivotX, pivotY);
  ctx.rotate(s.roll * 0.35);                       // 首かしげ（体ごと・控えめ）
  ctx.translate(-pivotX, -pivotY);

  // 全体の平行移動（首振り＝横シフト＋呼吸＋位置調整）
  const shiftX = s.x * W + s.yaw * W * 0.03 + RIG.faceX * W;
  const shiftY = breatheY + s.y * H + s.pitch * H * 0.02 + RIG.faceY * H;
  const gw = dw * RIG.scale, gh = dh * RIG.scale;
  const gx = dx + shiftX - (gw - dw) / 2;
  const gy = dy + shiftY - (gh - dh) / 2;

  // 体 → 顔 の順で同じ位置に重ねる（ズレない）
  if (PARTS.body.ok) ctx.drawImage(PARTS.body.img, gx, gy, gw, gh);
  ctx.drawImage(faceImg, gx, gy, gw, gh);
  ctx.restore();

  if (rigAdjust) {
    ctx.save();
    ctx.strokeStyle = c.main; ctx.lineWidth = 2; ctx.setLineDash([6, 4]);
    ctx.strokeRect(dx + 4, dy + 4, dw - 8, dh - 8);
    ctx.restore();
  }
}

// 表情選択（目・口の状態から4枚のどれかを返す）
function pickFace(s) {
  const eyeClosed = s.blink > RIG.blinkThresh;
  const mouthOpen = s.mouth > RIG.mouthThresh;
  if (eyeClosed && mouthOpen && PARTS.ec_mo.ok) return PARTS.ec_mo.img;
  if (eyeClosed && !mouthOpen && PARTS.ec_mc.ok) return PARTS.ec_mc.img;
  if (!eyeClosed && mouthOpen && PARTS.eo_mo.ok) return PARTS.eo_mo.img;
  if (!eyeClosed && !mouthOpen && s.smile > RIG.smileThresh && PARTS.smile.ok) return PARTS.smile.img;
  return PARTS.eo_mc.img; // 目開き口閉じ（基本）
}

function updateAvatar(lm, bs, ts) {
  const t = AV.target;
  if (lm && state.faceOK) {
    const nose = lm[NOSE_TIP];
    const e1 = eyeCenterN(EYE_R, lm), e2 = eyeCenterN(EYE_L, lm);
    const midx = (e1.x + e2.x) / 2, midy = (e1.y + e2.y) / 2;
    const d = Math.hypot(e2.x - e1.x, e2.y - e1.y) || 0.001;
    // 鏡像として自然に（roll/yaw/x を反転）
    t.roll = -Math.atan2(e2.y - e1.y, e2.x - e1.x);
    t.yaw = clamp(-((nose.x - midx) / d) * 1.4, -1, 1);
    t.pitch = clamp((((nose.y - midy) / d) - 0.62) * 1.8, -1, 1);
    const bl = Math.max(bs.eyeBlinkLeft || 0, bs.eyeBlinkRight || 0);
    t.blink = clamp(bl, 0, 1);
    t.mouth = clamp(bs.jawOpen || 0, 0, 1);
    t.smile = clamp(((bs.mouthSmileLeft || 0) + (bs.mouthSmileRight || 0)) * 0.7, 0, 1);
    t.x = -(nose.x - 0.5) * 0.08;
    t.y = (nose.y - 0.5) * 0.06;
    t.breath = Math.sin(ts / 2200) * 0.5 + 0.5;
  } else {
    // スタンバイ（自動まばたき＋ゆらぎ）
    t.roll = Math.sin(ts / 1800) * 0.035;
    t.yaw = Math.sin(ts / 2600) * 0.14;
    t.pitch = Math.sin(ts / 3100) * 0.06;
    const ph = (ts % 4000) / 4000;
    t.blink = ph > 0.95 ? Math.sin((ph - 0.95) / 0.05 * Math.PI) : 0;
    t.mouth = 0;
    t.smile = 0;
    t.x = Math.sin(ts / 2600) * 0.015;
    t.y = 0;
    t.breath = Math.sin(ts / 2200) * 0.5 + 0.5;
  }
  // blink/mouth は素早く（表情切替の反応を良く）、他は滑らかに
  const s = AV.cur;
  s.blink += (t.blink - s.blink) * 0.6;
  s.mouth += (t.mouth - s.mouth) * 0.6;
  s.smile += (t.smile - s.smile) * 0.5;
  for (const key of ["roll", "yaw", "pitch", "x", "y", "breath"]) {
    s[key] += (t[key] - s[key]) * 0.35;
  }
}



// ============================================================
// ボイスチェンジャー
// ============================================================
const voice = new VoiceChanger();
let vuTimer = 0;

// プリセットボタンを動的生成
(function buildVoicePresets() {
  const wrap = $("vcPresets");
  for (const key in VOICE_PRESETS) {
    const b = document.createElement("button");
    b.className = "vp" + (key === state.voicePreset ? " on" : "");
    b.dataset.k = key;
    b.textContent = VOICE_PRESETS[key].label;
    b.addEventListener("click", () => selectPreset(key));
    wrap.appendChild(b);
  }
})();

function selectPreset(key) {
  state.voicePreset = key;
  document.querySelectorAll(".vp").forEach((b) => b.classList.toggle("on", b.dataset.k === key));
  const p = VOICE_PRESETS[key];
  $("rgPitch").value = Math.round(p.pitch * 100);
  $("rgTone").value = Math.round(p.tone * 100);
  $("vPitch").textContent = p.pitch.toFixed(2);
  $("vTone").textContent = (p.tone >= 0 ? "+" : "") + Math.round(p.tone * 100);
  if (voice.running) voice.applyPreset(key);
}

// スライダーを触ったら手動調整モード（robot設定は現プリセットを引き継ぐ）
function manualVoice() {
  const pitch = Number($("rgPitch").value) / 100;
  const tone = Number($("rgTone").value) / 100;
  $("vPitch").textContent = pitch.toFixed(2);
  $("vTone").textContent = (tone >= 0 ? "+" : "") + Math.round(tone * 100);
  const robot = VOICE_PRESETS[state.voicePreset]
    ? VOICE_PRESETS[state.voicePreset].robot : 0;
  if (voice.running) voice.setParams({ pitch, tone, robot, wet: 1.0 });
}
$("rgPitch").addEventListener("input", manualVoice);
$("rgTone").addEventListener("input", manualVoice);

$("ckMonitor").addEventListener("change", (e) => voice.setMonitor(e.target.checked));

$("btnVoice").addEventListener("click", async () => {
  if (state.voiceOn) {
    // OFF
    await voice.stop();
    state.voiceOn = false;
    $("btnVoice").classList.remove("on");
    $("btnVoice").textContent = "🎙️ ボイチェン";
    $("vcPanel").classList.add("hidden");
    $("vuWrap").classList.add("hidden");
    $("lbMon").classList.add("hidden");
    $("ckMonitor").checked = false;
    clearInterval(vuTimer);
    return;
  }
  // ON
  if (!voice.supported) {
    alert("この端末/ブラウザではボイスチェンジャーを利用できません。");
    return;
  }
  $("btnVoice").textContent = "起動中…";
  try {
    await voice.start();
    voice.applyPreset(state.voicePreset);
    state.voiceOn = true;
    $("btnVoice").classList.add("on");
    $("btnVoice").textContent = "🎙️ ボイチェン ON";
    $("vcPanel").classList.remove("hidden");
    $("vuWrap").classList.remove("hidden");
    $("lbMon").classList.remove("hidden");
    selectPreset(state.voicePreset);
    // レベルメーター
    clearInterval(vuTimer);
    vuTimer = setInterval(() => {
      $("vuBar").style.width = Math.round(voice.getLevel() * 100) + "%";
    }, 80);
  } catch (err) {
    $("btnVoice").textContent = "🎙️ ボイチェン";
    let m = "マイクを起動できませんでした。";
    if (err && err.name === "NotAllowedError") {
      m = "マイクの使用がブロックされています。ブラウザのサイト設定でマイクを「許可」にしてください。";
    } else if (err && err.name === "NotFoundError") {
      m = "マイクが見つかりませんでした。";
    } else if (err && err.name === "NotReadableError") {
      m = "マイクを他のアプリが使用中の可能性があります。";
    }
    alert(m);
  }
});

// 配信ソフト等へ渡す用（コンソールから取得できるように）
window.STUDIOJ_VCAM = {
  getVideoStream: () => cv.captureStream ? cv.captureStream(30) : null,
  getAudioStream: () => voice.outStream,
  // 映像＋加工音声を1本のMediaStreamにまとめる
  getStream() {
    const v = this.getVideoStream();
    if (!v) return null;
    const a = this.getAudioStream();
    if (a) a.getAudioTracks().forEach((t) => v.addTrack(t));
    return v;
  }
};

// ============================================================
// HUD（ロゴ・ステータス）※ミラーの影響を受けない層
// ============================================================
function drawLogo(W, H) {
  const c = COLORS[state.color];
  ctx.save();
  const fs = Math.max(16, Math.round(H * 0.035));
  ctx.font = "italic 900 " + fs + "px 'Arial Black', 'Hiragino Sans', sans-serif";
  ctx.textAlign = "right";
  ctx.textBaseline = "bottom";
  const x = W - fs * 0.8, y = H - fs * 0.6;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = fs * 0.8;
  ctx.fillStyle = "#ffffff";
  ctx.fillText("STUDIO J", x, y);
  ctx.shadowBlur = 0;
  ctx.strokeStyle = c.main;
  ctx.lineWidth = 1;
  ctx.globalAlpha = 0.9;
  ctx.strokeText("STUDIO J", x, y);
  ctx.restore();
}

function drawStatus(W, H) {
  // モードAでロスト中は中央に案内（これは常時表示）
  if (state.mode === "A" && !state.faceOK) {
    ctx.save();
    const fs = Math.max(18, Math.round(H * 0.04));
    ctx.font = "900 " + fs + "px 'Arial Black', 'Hiragino Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowColor = "rgba(34,230,255,0.9)";
    ctx.shadowBlur = fs * 0.7;
    ctx.fillStyle = "#ffffff";
    ctx.fillText("PRIVACY GUARD", W / 2, H * 0.46);
    ctx.shadowBlur = 0;
    ctx.font = Math.round(fs * 0.5) + "px 'Hiragino Sans', sans-serif";
    ctx.fillStyle = "rgba(220,225,255,0.85)";
    ctx.fillText("顔を検出するまで自動ブラー中", W / 2, H * 0.46 + fs);
    ctx.restore();
  }

  // ステータスピル（UI表示中のみ＝配信画面には残らない）
  if (!uiVisible) return;
  ctx.save();
  const pw = 168, ph = 30;
  ctx.fillStyle = "rgba(10,12,24,0.72)";
  ctx.fill(roundRectPath(12, 12, pw, ph, 15));
  ctx.fillStyle = state.faceOK ? "#3dff9a" : "#ff5d6c";
  ctx.beginPath();
  ctx.arc(30, 27, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#dfe2ff";
  ctx.font = "600 13px 'Hiragino Sans', monospace, sans-serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText((state.faceOK ? "TRACK OK" : "LOST") + " / " + fps + "fps", 44, 28);
  ctx.restore();

  // ボイチェンのステータスピル
  if (state.voiceOn) {
    ctx.save();
    const c = COLORS[state.color];
    const label = "VOICE " + (VOICE_PRESETS[state.voicePreset]
      ? VOICE_PRESETS[state.voicePreset].label.replace(/^\S+\s*/, "") : "");
    ctx.font = "600 13px 'Hiragino Sans', monospace, sans-serif";
    const tw = ctx.measureText(label).width;
    const pw2 = tw + 46, ph2 = 30;
    ctx.fillStyle = "rgba(10,12,24,0.72)";
    ctx.fill(roundRectPath(12, 50, pw2, ph2, 15));
    ctx.fillStyle = c.main;
    ctx.beginPath();
    ctx.arc(30, 65, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#dfe2ff";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(label, 44, 66);
    ctx.restore();
  }
}

// ============================================================
// UIイベント
// ============================================================
function setMode(m) {
  state.mode = m;
  $("mA").classList.toggle("on", m === "A");
  $("mB").classList.toggle("on", m === "B");
  $("rowA").classList.toggle("hidden", m !== "A");
  $("rowB").classList.toggle("hidden", m !== "B");
  // モードA以外に切り替えたら調整パネルは畳む
  if (m !== "B") {
    rigAdjust = false;
    $("ckRig").checked = false;
    $("rigPanel").classList.add("hidden");
  }
}

$("mA").addEventListener("click", () => setMode("A"));
$("mB").addEventListener("click", () => setMode("B"));
$("ckBar").addEventListener("change", (e) => { state.barOn = e.target.checked; });
$("ckMirror").addEventListener("change", (e) => { state.mirror = e.target.checked; });
$("rgBihada").addEventListener("input", (e) => { state.bihada = Number(e.target.value); });

// --- モードB 位置調整 ---
$("ckRig").addEventListener("change", (e) => {
  rigAdjust = e.target.checked;
  $("rigPanel").classList.toggle("hidden", !rigAdjust);
});
$("rgFaceX").addEventListener("input", (e) => { RIG.faceX = Number(e.target.value) / 1000; });
$("rgFaceY").addEventListener("input", (e) => { RIG.faceY = Number(e.target.value) / 1000; });
$("rgScale").addEventListener("input", (e) => { RIG.scale = Number(e.target.value) / 100; });
$("btnRigReset").addEventListener("click", () => {
  RIG.faceX = 0; RIG.faceY = 0; RIG.scale = 1.00;
  $("rgFaceX").value = 0; $("rgFaceY").value = 0; $("rgScale").value = 100;
});

document.querySelectorAll(".sw").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".sw").forEach((b) => b.classList.remove("on"));
    btn.classList.add("on");
    state.color = btn.dataset.c;
  });
});

$("btnFs").addEventListener("click", () => {
  const el = $("stage");
  if (!document.fullscreenElement) {
    if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
  } else if (document.exitFullscreen) {
    document.exitFullscreen();
  }
});

$("btnReload").addEventListener("click", () => location.reload());

// コントロールの自動非表示
function pokeUI() {
  uiVisible = true;
  document.body.classList.remove("ui-hidden");
  clearTimeout(uiTimer);
  uiTimer = setTimeout(() => {
    if (state.running) {
      uiVisible = false;
      document.body.classList.add("ui-hidden");
    }
  }, 3200);
}
["pointermove", "pointerdown", "touchstart", "keydown"].forEach((ev) =>
  window.addEventListener(ev, pokeUI, { passive: true })
);

// ---- スタート ----
$("btnStart").addEventListener("click", async () => {
  $("hudStart").classList.add("hidden");
  $("loading").classList.remove("hidden");
  try {
    await Promise.all([initLandmarker(), startCamera()]);
    $("loading").classList.add("hidden");
    state.running = true;
    pokeUI();
    requestAnimationFrame(loop);
  } catch (err) {
    $("loading").classList.add("hidden");
    showError(err);
  }
});

// バックグラウンド復帰時に AudioContext を復活させる（iOS対策）
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && voice.running && voice.ctx && voice.ctx.state === "suspended") {
    voice.ctx.resume().catch(() => {});
  }
});

console.log("STUDIO J V-CAM v" + VERSION + " — on-device processing only");
