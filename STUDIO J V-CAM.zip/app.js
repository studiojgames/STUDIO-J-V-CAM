// ============================================================
// STUDIO J V-CAM v1.0.0
// 顔バレ防止フィルターカメラ（盛れモード / アバターモード）
// 映像はすべて端末内で処理。外部送信・録画なし。
// ============================================================

import { FaceLandmarker, FilesetResolver } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

const MP_WASM  = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const MP_MODEL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const VERSION  = "1.0.0";

// ---- ランドマーク定義（MediaPipe FaceMesh 478点） ----
const FACE_OVAL = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109];
const JAW = FACE_OVAL.slice(FACE_OVAL.indexOf(454), FACE_OVAL.indexOf(234) + 1);
const EYE_R = { outer: 33,  inner: 133, top: 159, bottom: 145, iris: 468 }; // 画面向かって左側の目
const EYE_L = { outer: 263, inner: 362, top: 386, bottom: 374, iris: 473 }; // 画面向かって右側の目
const MOUTH = { left: 61, right: 291, top: 13, bottom: 14 };
const NOSE_TIP = 1;

// ---- カラーテーマ ----
const COLORS = {
  pink:   { main: "#ff3d8d", glow: "rgba(255,61,141,0.85)", sub: "#ff9ec9" },
  cyan:   { main: "#22e6ff", glow: "rgba(34,230,255,0.85)",  sub: "#9ef4ff" },
  purple: { main: "#a86bff", glow: "rgba(168,107,255,0.85)", sub: "#d3b4ff" },
  gold:   { main: "#ffc93d", glow: "rgba(255,201,61,0.80)",  sub: "#ffe49e" }
};

// ---- 状態 ----
const state = {
  mode: "A",        // "A"=盛れ / "B"=アバター
  color: "pink",
  barOn: true,
  mirror: true,
  bihada: 60,
  running: false,
  lastFaceTime: 0,  // 最後に顔を検出した時刻
  faceOK: false
};

// ---- DOM ----
const $ = (id) => document.getElementById(id);
const video = $("cam");
const cv = $("view");
const ctx = cv.getContext("2d");

// オフスクリーン（ぼかし用・目の拡大用）
const blurC = document.createElement("canvas");
const blurCtx = blurC.getContext("2d");
const eyeC = document.createElement("canvas");
const eyeCtx = eyeC.getContext("2d");

let landmarker = null;
let lastVideoTime = -1;
let lastResult = null;
let lastLm = null;      // 直近のランドマーク（短時間ロスト時のバー維持用）
let fps = 0, fpsFrames = 0, fpsTime = 0;
let uiTimer = 0, uiVisible = true;


// ============================================================
// 初期化
// ============================================================
async function initLandmarker() {
  const fileset = await FilesetResolver.forVisionTasks(MP_WASM);
  landmarker = await FaceLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MP_MODEL, delegate: "GPU" },
    runningMode: "VIDEO",
    numFaces: 1,
    outputFaceBlendshapes: true,
    outputFacialTransformationMatrixes: false
  });
}

async function startCamera() {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: false
  });
  video.srcObject = stream;
  await video.play();
  cv.width = video.videoWidth || 1280;
  cv.height = video.videoHeight || 720;
}

function showError(err) {
  const el = $("errMsg");
  let msg = "";
  if (err && err.name === "NotAllowedError") {
    msg = "カメラの使用がブロックされています。ブラウザのサイト設定でカメラを「許可」にしてから、再読み込みしてください。";
  } else if (err && err.name === "NotFoundError") {
    msg = "カメラが見つかりませんでした。カメラ付きの端末で開くか、接続を確認してください。";
  } else if (err && err.name === "NotReadableError") {
    msg = "カメラを他のアプリが使用中の可能性があります。他のアプリを閉じてから再読み込みしてください。";
  } else {
    msg = "エラー: " + (err && err.message ? err.message : String(err));
  }
  el.textContent = msg;
  $("hudError").classList.remove("hidden");
}

// ============================================================
// メインループ
// ============================================================
function loop(ts) {
  if (!state.running) return;
  if (video.readyState >= 2) {
    if (video.currentTime !== lastVideoTime) {
      lastVideoTime = video.currentTime;
      try {
        lastResult = landmarker.detectForVideo(video, performance.now());
      } catch (e) { /* 一時的な検出エラーは無視 */ }
    }
    render(lastResult, ts);
  }
  updateFps(ts);
  requestAnimationFrame(loop);
}

function updateFps(ts) {
  fpsFrames++;
  if (ts - fpsTime > 500) {
    fps = Math.round(fpsFrames * 1000 / (ts - fpsTime));
    fpsFrames = 0;
    fpsTime = ts;
  }
}

function readBlend(result) {
  const map = {};
  if (result && result.faceBlendshapes && result.faceBlendshapes[0]) {
    for (const c of result.faceBlendshapes[0].categories) map[c.categoryName] = c.score;
  }
  return map;
}

function render(result, ts) {
  const W = cv.width, H = cv.height;
  const lm = result && result.faceLandmarks && result.faceLandmarks[0] ? result.faceLandmarks[0] : null;
  const bs = readBlend(result);
  const now = performance.now();
  if (lm) { state.lastFaceTime = now; lastLm = lm; }
  state.faceOK = (now - state.lastFaceTime) < 400;

  if (state.mode === "A") {
    ctx.save();
    if (state.mirror) { ctx.translate(W, 0); ctx.scale(-1, 1); }
    renderModeA(lm, W, H);
    ctx.restore();
  } else {
    // モードBはアバター絵なのでミラーしない（首振りの符号だけ内部で調整）
    renderModeB(lm, bs, W, H, ts);
  }

  drawLogo(W, H);
  drawStatus(W, H);
}

// ============================================================
// モードA：盛れモード（美肌・小顔シェード・目デカ・ネオンバー）
// ============================================================
function renderModeA(lm, W, H) {
  ctx.drawImage(video, 0, 0, W, H);

  // 追跡できていない間は必ず全面ブラー（顔バレ事故防止・フェイルセーフ）
  const useLm = lm || (state.faceOK ? lastLm : null);
  if (!useLm) {
    privacyBlur(W, H);
    return;
  }

  // --- 美肌：顔領域にソフトブラーを重ねる ---
  const alpha = (state.bihada / 100) * 0.85;
  if (alpha > 0.02) {
    const b = makeBlur(10);
    ctx.save();
    ctx.clip(faceOvalPath(useLm, W, H));
    ctx.globalAlpha = alpha;
    ctx.drawImage(b, 0, 0, W, H);
    ctx.globalAlpha = 1;
    ctx.restore();

    // 目と口はシャープに戻す（ぼやけ防止）
    sharpMouth(useLm, W, H);
    if (!state.barOn) {
      sharpEye(EYE_R, useLm, W, H);
      sharpEye(EYE_L, useLm, W, H);
    }
  }

  // --- 小顔シェーディング（輪郭に沿った柔らかい影） ---
  jawShade(useLm, W, H);

  // --- 目デカ（バーOFF時のみ） ---
  if (!state.barOn) {
    magnifyEye(EYE_R, useLm, W, H);
    magnifyEye(EYE_L, useLm, W, H);
  }

  // --- トーンアップ（血色・透明感） ---
  ctx.save();
  ctx.globalCompositeOperation = "soft-light";
  ctx.fillStyle = "rgba(255,214,222,0.30)";
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = "screen";
  ctx.fillStyle = "rgba(255,240,250,0.05)";
  ctx.fillRect(0, 0, W, H);
  ctx.restore();

  // --- 目元ネオンバー ---
  if (state.barOn) neonBar(useLm, W, H);
}

function faceOvalPath(lm, W, H) {
  const p = new Path2D();
  for (let i = 0; i < FACE_OVAL.length; i++) {
    const pt = lm[FACE_OVAL[i]];
    const x = pt.x * W, y = pt.y * H;
    if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
  }
  p.closePath();
  return p;
}

// 縮小→拡大で作る軽量ブラー（Safari含む全ブラウザ対応）
function makeBlur(divisor) {
  const bw = Math.max(8, Math.round(cv.width / divisor));
  const bh = Math.max(8, Math.round(cv.height / divisor));
  blurC.width = bw; blurC.height = bh;
  blurCtx.drawImage(video, 0, 0, bw, bh);
  return blurC;
}

function privacyBlur(W, H) {
  const bw = 24, bh = Math.max(2, Math.round(bw * H / W));
  blurC.width = bw; blurC.height = bh;
  blurCtx.drawImage(video, 0, 0, bw, bh);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(blurC, 0, 0, W, H);
  ctx.fillStyle = "rgba(8,8,16,0.35)";
  ctx.fillRect(0, 0, W, H);
}

function sharpEye(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner], t = lm[eye.top], b = lm[eye.bottom];
  const cx = (o.x + i2.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const rw = Math.hypot((o.x - i2.x) * W, (o.y - i2.y) * H) * 0.85;
  const rh = Math.max(8, Math.abs(b.y - t.y) * H * 1.8);
  sharpRegion(cx, cy, rw, rh, W, H);
}

function sharpMouth(lm, W, H) {
  const l = lm[MOUTH.left], r = lm[MOUTH.right], t = lm[MOUTH.top], b = lm[MOUTH.bottom];
  const cx = (l.x + r.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const mw = Math.hypot((r.x - l.x) * W, (r.y - l.y) * H);
  sharpRegion(cx, cy, mw * 0.78, mw * 0.5, W, H);
}

function sharpRegion(cx, cy, rw, rh, W, H) {
  ctx.save();
  const p = new Path2D();
  p.ellipse(cx, cy, rw, rh, 0, 0, Math.PI * 2);
  ctx.clip(p);
  ctx.globalAlpha = 0.9;
  ctx.drawImage(video, 0, 0, W, H);
  ctx.globalAlpha = 1;
  ctx.restore();
}

function jawShade(lm, W, H) {
  const a = lm[234], b = lm[454];
  const fw = Math.hypot((b.x - a.x) * W, (b.y - a.y) * H);
  const p = new Path2D();
  for (let i = 0; i < JAW.length; i++) {
    const pt = lm[JAW[i]];
    const x = pt.x * W, y = pt.y * H;
    if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
  }
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "rgba(70,35,30,0.10)";
  ctx.lineWidth = fw * 0.10;
  ctx.shadowColor = "rgba(70,35,30,0.32)";
  ctx.shadowBlur = fw * 0.08;
  ctx.stroke(p);
  ctx.restore();
}

function magnifyEye(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner], t = lm[eye.top], b = lm[eye.bottom];
  const cx = (o.x + i2.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const ew = Math.hypot((o.x - i2.x) * W, (o.y - i2.y) * H) * 1.9;
  const eh = Math.max(12, Math.abs(b.y - t.y) * H * 3.2);
  const k = 1.12; // 拡大率（控えめ）
  const sw = ew, sh = eh, dw = ew * k, dh = eh * k;
  const sx = cx - sw / 2, sy = cy - sh / 2;
  const dx = cx - dw / 2, dy = cy - dh / 2;

  eyeC.width = Math.max(2, Math.ceil(dw));
  eyeC.height = Math.max(2, Math.ceil(dh));
  eyeCtx.clearRect(0, 0, eyeC.width, eyeC.height);
  eyeCtx.drawImage(video, sx, sy, sw, sh, 0, 0, dw, dh);
  // 縁を柔らかくフェード
  const g = eyeCtx.createRadialGradient(dw / 2, dh / 2, Math.min(dw, dh) * 0.25, dw / 2, dh / 2, Math.min(dw, dh) * 0.52);
  g.addColorStop(0, "rgba(0,0,0,1)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  eyeCtx.globalCompositeOperation = "destination-in";
  eyeCtx.fillStyle = g;
  eyeCtx.fillRect(0, 0, eyeC.width, eyeC.height);
  eyeCtx.globalCompositeOperation = "source-over";
  ctx.drawImage(eyeC, dx, dy);
}

function eyeCenterPx(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner];
  return { x: (o.x + i2.x) / 2 * W, y: (o.y + i2.y) / 2 * H };
}

function roundRectPath(x, y, w, h, r) {
  const p = new Path2D();
  p.moveTo(x + r, y);
  p.lineTo(x + w - r, y);
  p.arcTo(x + w, y, x + w, y + r, r);
  p.lineTo(x + w, y + h - r);
  p.arcTo(x + w, y + h, x + w - r, y + h, r);
  p.lineTo(x + r, y + h);
  p.arcTo(x, y + h, x, y + h - r, r);
  p.lineTo(x, y + r);
  p.arcTo(x, y, x + r, y, r);
  p.closePath();
  return p;
}

function neonBar(lm, W, H) {
  const c = COLORS[state.color];
  const e1 = eyeCenterPx(EYE_R, lm, W, H);
  const e2 = eyeCenterPx(EYE_L, lm, W, H);
  const cx = (e1.x + e2.x) / 2, cy = (e1.y + e2.y) / 2;
  const d = Math.hypot(e2.x - e1.x, e2.y - e1.y);
  const ang = Math.atan2(e2.y - e1.y, e2.x - e1.x);
  const bw = d * 2.35;
  const bh = Math.max(18, d * 0.62);
  const r = bh * 0.35;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(ang);
  const p = roundRectPath(-bw / 2, -bh / 2, bw, bh, r);

  // 本体（黒ガラス）＋外側グロー
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = bh * 0.9;
  ctx.fillStyle = "rgba(10,10,18,0.93)";
  ctx.fill(p);
  ctx.shadowBlur = 0;

  // ガラスの光沢
  const g = ctx.createLinearGradient(0, -bh / 2, 0, bh / 2);
  g.addColorStop(0, "rgba(255,255,255,0.10)");
  g.addColorStop(0.5, "rgba(255,255,255,0.02)");
  g.addColorStop(1, "rgba(255,255,255,0.10)");
  ctx.fillStyle = g;
  ctx.fill(p);

  // ネオン縁取り
  ctx.lineWidth = Math.max(2, bh * 0.08);
  ctx.strokeStyle = c.main;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = bh * 0.6;
  ctx.stroke(p);

  // センターのスキャンライン
  ctx.shadowBlur = 0;
  ctx.strokeStyle = c.sub;
  ctx.globalAlpha = 0.5;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-bw / 2 + r, 0);
  ctx.lineTo(bw / 2 - r, 0);
  ctx.stroke();
  ctx.restore();
}

// ============================================================
// モードB：アニメアバターVTuber（1枚絵ベース Live2D風）
// avatar.jpg を読み込み、目・口・首をトラッキングで動かす
// ============================================================

// アバター画像の読み込み
const avatarImg = new Image();
let avatarReady = false;
avatarImg.onload = () => { avatarReady = true; };
avatarImg.onerror = () => { avatarReady = false; };
avatarImg.src = "avatar.jpg?v=20260722a";

// 顔パーツの位置設定（画像内の正規化座標 0..1）。スライダーで調整可能。
const RIG = {
  faceCx: 0.50,   // 顔の中心X
  eyeY:   0.40,   // 目の高さY
  eyeDx:  0.115,  // 目の左右間隔（中心からの距離）
  eyeW:   0.105,  // 片目の幅
  eyeH:   0.052,  // 片目の高さ
  mouthY: 0.575,  // 口の高さY
  mouthW: 0.075,  // 口の半幅
  mouthH: 0.030,  // 口の高さ
  scale:  1.00    // 全体スケール
};

// 駆動値（スムージング付き）
function newDriver() {
  return { roll: 0, yaw: 0, pitch: 0, blinkL: 0, blinkR: 0,
           jaw: 0, smile: 0, breath: 0, x: 0, y: 0 };
}
const AV = { cur: newDriver(), target: newDriver() };

// 背景パーティクル（アバターの周りに浮遊）
const particles = [];
for (let i = 0; i < 36; i++) {
  particles.push({
    x: Math.random(), y: Math.random(),
    r: Math.random() * 2.0 + 0.6,
    sp: Math.random() * 0.0010 + 0.0003,
    tw: Math.random() * Math.PI * 2
  });
}

function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }

function eyeCenterN(eye, lm) {
  const o = lm[eye.outer], i2 = lm[eye.inner];
  return { x: (o.x + i2.x) / 2, y: (o.y + i2.y) / 2 };
}

function renderModeB(lm, bs, W, H, ts) {
  const c = COLORS[state.color];

  // --- 背景 ---
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, "#05060f");
  bg.addColorStop(0.6, "#0a0c22");
  bg.addColorStop(1, "#0f0d2e");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const rg = ctx.createRadialGradient(W / 2, H * 0.42, 10, W / 2, H * 0.42, H * 0.6);
  const gcol = c.glow.replace(/0\.\d+/, "0.14");
  rg.addColorStop(0, gcol);
  rg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = rg;
  ctx.fillRect(0, 0, W, H);

  // パーティクル
  ctx.save();
  for (const pt of particles) {
    pt.y -= pt.sp;
    if (pt.y < -0.05) { pt.y = 1.05; pt.x = Math.random(); }
    const tw = 0.3 + 0.3 * Math.sin(ts / 700 + pt.tw);
    ctx.globalAlpha = tw;
    ctx.fillStyle = c.sub;
    ctx.beginPath();
    ctx.arc(pt.x * W, pt.y * H, pt.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // 画像未読込ならプレースホルダ
  if (!avatarReady) {
    ctx.save();
    ctx.fillStyle = "rgba(220,225,255,0.8)";
    ctx.font = "600 " + Math.round(H * 0.03) + "px 'Hiragino Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("アバター画像を読み込み中…", W / 2, H / 2);
    ctx.restore();
    return;
  }

  updateAvatar(lm, bs, ts);
  drawAvatar(W, H, ts);
}

function updateAvatar(lm, bs, ts) {
  const t = AV.target;
  if (lm && state.faceOK) {
    const nose = lm[NOSE_TIP];
    const e1 = eyeCenterN(EYE_R, lm), e2 = eyeCenterN(EYE_L, lm);
    const midx = (e1.x + e2.x) / 2, midy = (e1.y + e2.y) / 2;
    const d = Math.hypot(e2.x - e1.x, e2.y - e1.y) || 0.001;
    // 鏡像として自然に見えるよう roll/yaw/x を反転
    t.roll = -Math.atan2(e2.y - e1.y, e2.x - e1.x);
    t.yaw = clamp(-((nose.x - midx) / d) * 1.4, -1, 1);
    t.pitch = clamp((((nose.y - midy) / d) - 0.62) * 1.8, -1, 1);
    t.blinkL = clamp(bs.eyeBlinkLeft || 0, 0, 1);
    t.blinkR = clamp(bs.eyeBlinkRight || 0, 0, 1);
    t.jaw = clamp((bs.jawOpen || 0) * 1.6, 0, 1);
    t.smile = clamp(((bs.mouthSmileLeft || 0) + (bs.mouthSmileRight || 0)) * 0.6, 0, 1);
    t.x = -(nose.x - 0.5) * 0.10;
    t.y = (nose.y - 0.5) * 0.08;
    t.breath = Math.sin(ts / 2200) * 0.5 + 0.5;
  } else {
    // スタンバイ（自動まばたき＋ゆらぎ）
    t.roll = Math.sin(ts / 1800) * 0.04;
    t.yaw = Math.sin(ts / 2600) * 0.18;
    t.pitch = Math.sin(ts / 3100) * 0.08;
    const ph = (ts % 3800) / 3800;
    const bl = ph > 0.94 ? Math.sin((ph - 0.94) / 0.06 * Math.PI) : 0;
    t.blinkL = bl; t.blinkR = bl;
    t.jaw = 0;
    t.smile = 0;
    t.x = Math.sin(ts / 2600) * 0.02;
    t.y = 0;
    t.breath = Math.sin(ts / 2200) * 0.5 + 0.5;
  }
  const s = AV.cur, k = 0.4;
  for (const key of Object.keys(t)) s[key] += (t[key] - s[key]) * k;
}

function drawAvatar(W, H, ts) {
  const s = AV.cur;
  const c = COLORS[state.color];

  // 画像を画面にフィット（アスペクト維持でカバー）
  const iw = avatarImg.width, ih = avatarImg.height;
  const scale = Math.max(W / iw, H / ih) * RIG.scale;
  const dw = iw * scale, dh = ih * scale;
  const breathe = (s.breath - 0.5) * H * 0.006;
  const dx = (W - dw) / 2 + s.x * W;
  const dy = (H - dh) / 2 + s.y * H + breathe;

  // 画像内パーツ座標 → 画面座標へ変換するヘルパ
  function px(nx, ny) {
    return { x: dx + nx * dw, y: dy + ny * dh };
  }

  ctx.save();

  // 首の傾き（画像全体を顔中心まわりに回転＋ヨー/ピッチ視差）
  const pivot = px(RIG.faceCx, RIG.eyeY);
  ctx.translate(pivot.x, pivot.y);
  ctx.rotate(s.roll * 0.55);
  const skewX = s.yaw * 0.05;
  const shiftX = s.yaw * W * 0.02;
  const shiftY = s.pitch * H * 0.015;
  ctx.transform(1, 0, skewX, 1, shiftX, shiftY);
  ctx.translate(-pivot.x, -pivot.y);

  // ベース画像
  ctx.drawImage(avatarImg, dx, dy, dw, dh);

  // --- 目：まばたき ---
  drawEyeLid(EYE_R_SIDE, s.blinkR, dx, dy, dw, dh);
  drawEyeLid(EYE_L_SIDE, s.blinkL, dx, dy, dw, dh);

  // --- 口：開閉 ---
  drawMouthRig(s, dx, dy, dw, dh);

  ctx.restore();

  // 調整モードならガイド表示
  if (rigAdjust) drawRigGuides(dx, dy, dw, dh);
}

// 目の左右指定（画像内座標）
const EYE_R_SIDE = -1; // faceCxより左（向かって左）
const EYE_L_SIDE = 1;

// 肌色サンプル（目の上あたりの色を1回だけ拾ってキャッシュ）
let skinSample = null;
function getSkinColor() {
  if (skinSample) return skinSample;
  try {
    const sc = document.createElement("canvas");
    sc.width = avatarImg.width; sc.height = avatarImg.height;
    const sx = sc.getContext("2d");
    sx.drawImage(avatarImg, 0, 0);
    // 目の少し上（額の下）の肌をサンプル
    const px = Math.round((RIG.faceCx + 0.06) * avatarImg.width);
    const py = Math.round((RIG.eyeY - 0.05) * avatarImg.height);
    const d = sx.getImageData(px, py, 1, 1).data;
    skinSample = `rgb(${d[0]},${d[1]},${d[2]})`;
  } catch (e) {
    skinSample = "#e8c4a8";
  }
  return skinSample;
}

function drawEyeLid(side, blink, dx, dy, dw, dh) {
  if (blink < 0.08) return; // 開いてる時は元画像のまま
  const cx = dx + (RIG.faceCx + side * RIG.eyeDx) * dw;
  const cy = dy + RIG.eyeY * dh;
  const ew = RIG.eyeW * dw;
  const eh = RIG.eyeH * dh;
  const skin = getSkinColor();

  ctx.save();
  // 目領域だけにクリップ
  const clip = new Path2D();
  clip.ellipse(cx, cy, ew * 1.05, eh * 1.25, 0, 0, Math.PI * 2);
  ctx.clip(clip);
  // 上まぶた（肌色）を blink 量に応じて下ろす
  const lidBottom = cy - eh * 1.25 + (eh * 2.5) * blink;
  ctx.fillStyle = skin;
  ctx.fillRect(cx - ew * 1.1, cy - eh * 1.3, ew * 2.2, (lidBottom - (cy - eh * 1.3)));
  // まつげライン（閉じ目の線）
  if (blink > 0.45) {
    ctx.strokeStyle = "rgba(45,30,26," + Math.min(1, blink) + ")";
    ctx.lineWidth = Math.max(1.5, eh * 0.16);
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(cx - ew * 0.92, lidBottom);
    ctx.quadraticCurveTo(cx, lidBottom + eh * 0.35, cx + ew * 0.92, lidBottom - eh * 0.1);
    ctx.stroke();
  }
  ctx.restore();
}

function drawMouthRig(s, dx, dy, dw, dh) {
  const cx = dx + RIG.faceCx * dw;
  const cy = dy + RIG.mouthY * dh;
  const mw = RIG.mouthW * dw;
  const mh = RIG.mouthH * dh;
  const open = s.jaw;

  if (open < 0.05 && s.smile < 0.15) return; // ニュートラルは元画像のまま

  ctx.save();
  if (open >= 0.05) {
    // 口を開ける：口内を暗く描いて、下唇を下げる
    const oh = mh + open * dh * 0.09;
    // 口内
    const grad = ctx.createRadialGradient(cx, cy + oh * 0.2, 1, cx, cy + oh * 0.2, mw);
    grad.addColorStop(0, "#3a1418");
    grad.addColorStop(1, "#5c2028");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(cx - mw, cy);
    ctx.quadraticCurveTo(cx, cy - oh * 0.3, cx + mw, cy);
    ctx.quadraticCurveTo(cx + mw * 0.7, cy + oh * 1.1, cx, cy + oh * 1.25);
    ctx.quadraticCurveTo(cx - mw * 0.7, cy + oh * 1.1, cx - mw, cy);
    ctx.closePath();
    ctx.fill();
    // 上の歯
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.moveTo(cx - mw * 0.75, cy + oh * 0.05);
    ctx.quadraticCurveTo(cx, cy - oh * 0.15, cx + mw * 0.75, cy + oh * 0.05);
    ctx.quadraticCurveTo(cx, cy + oh * 0.28, cx - mw * 0.75, cy + oh * 0.05);
    ctx.closePath();
    ctx.fill();
    // 舌
    ctx.fillStyle = "rgba(220,110,120,0.75)";
    ctx.beginPath();
    ctx.ellipse(cx, cy + oh * 0.72, mw * 0.5, oh * 0.34, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// 調整モードのガイド線
let rigAdjust = false;
function drawRigGuides(dx, dy, dw, dh) {
  const c = COLORS[state.color];
  ctx.save();
  ctx.strokeStyle = c.main;
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 4]);
  // 目
  for (const side of [-1, 1]) {
    const cx = dx + (RIG.faceCx + side * RIG.eyeDx) * dw;
    const cy = dy + RIG.eyeY * dh;
    ctx.beginPath();
    ctx.ellipse(cx, cy, RIG.eyeW * dw, RIG.eyeH * dh, 0, 0, Math.PI * 2);
    ctx.stroke();
  }
  // 口
  const mx = dx + RIG.faceCx * dw;
  const my = dy + RIG.mouthY * dh;
  ctx.beginPath();
  ctx.ellipse(mx, my, RIG.mouthW * dw, RIG.mouthH * dh, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}


// ============================================================
// HUD（ロゴ・ステータス）※ミラーの影響を受けない層
// ============================================================
function drawLogo(W, H) {
  const c = COLORS[state.color];
  ctx.save();
  const fs = Math.max(16, Math.round(H * 0.035));
  ctx.font = "italic 900 " + fs + "px 'Arial Black', 'Hiragino Sans', sans-serif";
  ctx.textAlign = "right";
  ctx.textBaseline = "bottom";
  const x = W - fs * 0.8, y = H - fs * 0.6;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = fs * 0.8;
  ctx.fillStyle = "#ffffff";
  ctx.fillText("STUDIO J", x, y);
  ctx.shadowBlur = 0;
  ctx.strokeStyle = c.main;
  ctx.lineWidth = 1;
  ctx.globalAlpha = 0.9;
  ctx.strokeText("STUDIO J", x, y);
  ctx.restore();
}

function drawStatus(W, H) {
  // モードAでロスト中は中央に案内（これは常時表示）
  if (state.mode === "A" && !state.faceOK) {
    ctx.save();
    const fs = Math.max(18, Math.round(H * 0.04));
    ctx.font = "900 " + fs + "px 'Arial Black', 'Hiragino Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowColor = "rgba(34,230,255,0.9)";
    ctx.shadowBlur = fs * 0.7;
    ctx.fillStyle = "#ffffff";
    ctx.fillText("PRIVACY GUARD", W / 2, H * 0.46);
    ctx.shadowBlur = 0;
    ctx.font = Math.round(fs * 0.5) + "px 'Hiragino Sans', sans-serif";
    ctx.fillStyle = "rgba(220,225,255,0.85)";
    ctx.fillText("顔を検出するまで自動ブラー中", W / 2, H * 0.46 + fs);
    ctx.restore();
  }

  // ステータスピル（UI表示中のみ＝配信画面には残らない）
  if (!uiVisible) return;
  ctx.save();
  const pw = 168, ph = 30;
  ctx.fillStyle = "rgba(10,12,24,0.72)";
  ctx.fill(roundRectPath(12, 12, pw, ph, 15));
  ctx.fillStyle = state.faceOK ? "#3dff9a" : "#ff5d6c";
  ctx.beginPath();
  ctx.arc(30, 27, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#dfe2ff";
  ctx.font = "600 13px 'Hiragino Sans', monospace, sans-serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText((state.faceOK ? "TRACK OK" : "LOST") + " / " + fps + "fps", 44, 28);
  ctx.restore();
}

// ============================================================
// UIイベント
// ============================================================
function setMode(m) {
  state.mode = m;
  $("mA").classList.toggle("on", m === "A");
  $("mB").classList.toggle("on", m === "B");
  $("rowA").classList.toggle("hidden", m !== "A");
  $("rowB").classList.toggle("hidden", m !== "B");
  // モードA以外に切り替えたら調整パネルは畳む
  if (m !== "B") {
    rigAdjust = false;
    $("ckRig").checked = false;
    $("rigPanel").classList.add("hidden");
  }
}

$("mA").addEventListener("click", () => setMode("A"));
$("mB").addEventListener("click", () => setMode("B"));
$("ckBar").addEventListener("change", (e) => { state.barOn = e.target.checked; });
$("ckMirror").addEventListener("change", (e) => { state.mirror = e.target.checked; });
$("rgBihada").addEventListener("input", (e) => { state.bihada = Number(e.target.value); });

// --- モードB 位置調整 ---
$("ckRig").addEventListener("change", (e) => {
  rigAdjust = e.target.checked;
  $("rigPanel").classList.toggle("hidden", !rigAdjust);
});
$("rgEyeY").addEventListener("input", (e) => { RIG.eyeY = Number(e.target.value) / 1000; });
$("rgEyeDx").addEventListener("input", (e) => { RIG.eyeDx = Number(e.target.value) / 1000; });
$("rgMouthY").addEventListener("input", (e) => { RIG.mouthY = Number(e.target.value) / 1000; });
$("rgScale").addEventListener("input", (e) => { RIG.scale = Number(e.target.value) / 100; });
$("btnRigReset").addEventListener("click", () => {
  RIG.eyeY = 0.40; RIG.eyeDx = 0.115; RIG.mouthY = 0.575; RIG.scale = 1.00;
  $("rgEyeY").value = 400; $("rgEyeDx").value = 115; $("rgMouthY").value = 575; $("rgScale").value = 100;
});

document.querySelectorAll(".sw").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".sw").forEach((b) => b.classList.remove("on"));
    btn.classList.add("on");
    state.color = btn.dataset.c;
  });
});

$("btnFs").addEventListener("click", () => {
  const el = $("stage");
  if (!document.fullscreenElement) {
    if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
  } else if (document.exitFullscreen) {
    document.exitFullscreen();
  }
});

$("btnReload").addEventListener("click", () => location.reload());

// コントロールの自動非表示
function pokeUI() {
  uiVisible = true;
  document.body.classList.remove("ui-hidden");
  clearTimeout(uiTimer);
  uiTimer = setTimeout(() => {
    if (state.running) {
      uiVisible = false;
      document.body.classList.add("ui-hidden");
    }
  }, 3200);
}
["pointermove", "pointerdown", "touchstart", "keydown"].forEach((ev) =>
  window.addEventListener(ev, pokeUI, { passive: true })
);

// ---- スタート ----
$("btnStart").addEventListener("click", async () => {
  $("hudStart").classList.add("hidden");
  $("loading").classList.remove("hidden");
  try {
    await Promise.all([initLandmarker(), startCamera()]);
    $("loading").classList.add("hidden");
    state.running = true;
    pokeUI();
    requestAnimationFrame(loop);
  } catch (err) {
    $("loading").classList.add("hidden");
    showError(err);
  }
});

console.log("STUDIO J V-CAM v" + VERSION + " — on-device processing only");
