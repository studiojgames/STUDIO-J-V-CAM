// ============================================================
// STUDIO J V-CAM v1.0.0
// 顔バレ防止フィルターカメラ（盛れモード / アバターモード）
// 映像はすべて端末内で処理。外部送信・録画なし。
// ============================================================

import { FaceLandmarker, FilesetResolver } from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

const MP_WASM  = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const MP_MODEL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";
const VERSION  = "1.0.0";

// ---- ランドマーク定義（MediaPipe FaceMesh 478点） ----
const FACE_OVAL = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109];
const JAW = FACE_OVAL.slice(FACE_OVAL.indexOf(454), FACE_OVAL.indexOf(234) + 1);
const EYE_R = { outer: 33,  inner: 133, top: 159, bottom: 145, iris: 468 }; // 画面向かって左側の目
const EYE_L = { outer: 263, inner: 362, top: 386, bottom: 374, iris: 473 }; // 画面向かって右側の目
const MOUTH = { left: 61, right: 291, top: 13, bottom: 14 };
const NOSE_TIP = 1;

// ---- カラーテーマ ----
const COLORS = {
  pink:   { main: "#ff3d8d", glow: "rgba(255,61,141,0.85)", sub: "#ff9ec9" },
  cyan:   { main: "#22e6ff", glow: "rgba(34,230,255,0.85)",  sub: "#9ef4ff" },
  purple: { main: "#a86bff", glow: "rgba(168,107,255,0.85)", sub: "#d3b4ff" },
  gold:   { main: "#ffc93d", glow: "rgba(255,201,61,0.80)",  sub: "#ffe49e" }
};

// ---- 状態 ----
const state = {
  mode: "A",        // "A"=盛れ / "B"=アバター
  color: "pink",
  barOn: true,
  mirror: true,
  bihada: 60,
  running: false,
  lastFaceTime: 0,  // 最後に顔を検出した時刻
  faceOK: false
};

// ---- DOM ----
const $ = (id) => document.getElementById(id);
const video = $("cam");
const cv = $("view");
const ctx = cv.getContext("2d");

// オフスクリーン（ぼかし用・目の拡大用）
const blurC = document.createElement("canvas");
const blurCtx = blurC.getContext("2d");
const eyeC = document.createElement("canvas");
const eyeCtx = eyeC.getContext("2d");

let landmarker = null;
let lastVideoTime = -1;
let lastResult = null;
let lastLm = null;      // 直近のランドマーク（短時間ロスト時のバー維持用）
let fps = 0, fpsFrames = 0, fpsTime = 0;
let uiTimer = 0, uiVisible = true;

// ---- アバター駆動値（スムージング付き） ----
function newDriver() {
  return { x: 0.5, y: 0.46, roll: 0, yaw: 0, pitch: 0,
           blinkL: 0, blinkR: 0, jaw: 0, smile: 0.2,
           browUp: 0, browDn: 0, gx: 0, gy: 0 };
}
const AV = { cur: newDriver(), target: newDriver() };

// アバターモード背景のパーティクル
const particles = [];
for (let i = 0; i < 40; i++) {
  particles.push({
    x: Math.random(), y: Math.random(),
    r: Math.random() * 2.2 + 0.8,
    sp: Math.random() * 0.0012 + 0.0004,
    tw: Math.random() * Math.PI * 2
  });
}

// ============================================================
// 初期化
// ============================================================
async function initLandmarker() {
  const fileset = await FilesetResolver.forVisionTasks(MP_WASM);
  landmarker = await FaceLandmarker.createFromOptions(fileset, {
    baseOptions: { modelAssetPath: MP_MODEL, delegate: "GPU" },
    runningMode: "VIDEO",
    numFaces: 1,
    outputFaceBlendshapes: true,
    outputFacialTransformationMatrixes: false
  });
}

async function startCamera() {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: false
  });
  video.srcObject = stream;
  await video.play();
  cv.width = video.videoWidth || 1280;
  cv.height = video.videoHeight || 720;
}

function showError(err) {
  const el = $("errMsg");
  let msg = "";
  if (err && err.name === "NotAllowedError") {
    msg = "カメラの使用がブロックされています。ブラウザのサイト設定でカメラを「許可」にしてから、再読み込みしてください。";
  } else if (err && err.name === "NotFoundError") {
    msg = "カメラが見つかりませんでした。カメラ付きの端末で開くか、接続を確認してください。";
  } else if (err && err.name === "NotReadableError") {
    msg = "カメラを他のアプリが使用中の可能性があります。他のアプリを閉じてから再読み込みしてください。";
  } else {
    msg = "エラー: " + (err && err.message ? err.message : String(err));
  }
  el.textContent = msg;
  $("hudError").classList.remove("hidden");
}

// ============================================================
// メインループ
// ============================================================
function loop(ts) {
  if (!state.running) return;
  if (video.readyState >= 2) {
    if (video.currentTime !== lastVideoTime) {
      lastVideoTime = video.currentTime;
      try {
        lastResult = landmarker.detectForVideo(video, performance.now());
      } catch (e) { /* 一時的な検出エラーは無視 */ }
    }
    render(lastResult, ts);
  }
  updateFps(ts);
  requestAnimationFrame(loop);
}

function updateFps(ts) {
  fpsFrames++;
  if (ts - fpsTime > 500) {
    fps = Math.round(fpsFrames * 1000 / (ts - fpsTime));
    fpsFrames = 0;
    fpsTime = ts;
  }
}

function readBlend(result) {
  const map = {};
  if (result && result.faceBlendshapes && result.faceBlendshapes[0]) {
    for (const c of result.faceBlendshapes[0].categories) map[c.categoryName] = c.score;
  }
  return map;
}

function render(result, ts) {
  const W = cv.width, H = cv.height;
  const lm = result && result.faceLandmarks && result.faceLandmarks[0] ? result.faceLandmarks[0] : null;
  const bs = readBlend(result);
  const now = performance.now();
  if (lm) { state.lastFaceTime = now; lastLm = lm; }
  state.faceOK = (now - state.lastFaceTime) < 400;

  ctx.save();
  if (state.mirror) { ctx.translate(W, 0); ctx.scale(-1, 1); }
  if (state.mode === "A") renderModeA(lm, W, H);
  else renderModeB(lm, bs, W, H, ts);
  ctx.restore();

  drawLogo(W, H);
  drawStatus(W, H);
}

// ============================================================
// モードA：盛れモード（美肌・小顔シェード・目デカ・ネオンバー）
// ============================================================
function renderModeA(lm, W, H) {
  ctx.drawImage(video, 0, 0, W, H);

  // 追跡できていない間は必ず全面ブラー（顔バレ事故防止・フェイルセーフ）
  const useLm = lm || (state.faceOK ? lastLm : null);
  if (!useLm) {
    privacyBlur(W, H);
    return;
  }

  // --- 美肌：顔領域にソフトブラーを重ねる ---
  const alpha = (state.bihada / 100) * 0.85;
  if (alpha > 0.02) {
    const b = makeBlur(10);
    ctx.save();
    ctx.clip(faceOvalPath(useLm, W, H));
    ctx.globalAlpha = alpha;
    ctx.drawImage(b, 0, 0, W, H);
    ctx.globalAlpha = 1;
    ctx.restore();

    // 目と口はシャープに戻す（ぼやけ防止）
    sharpMouth(useLm, W, H);
    if (!state.barOn) {
      sharpEye(EYE_R, useLm, W, H);
      sharpEye(EYE_L, useLm, W, H);
    }
  }

  // --- 小顔シェーディング（輪郭に沿った柔らかい影） ---
  jawShade(useLm, W, H);

  // --- 目デカ（バーOFF時のみ） ---
  if (!state.barOn) {
    magnifyEye(EYE_R, useLm, W, H);
    magnifyEye(EYE_L, useLm, W, H);
  }

  // --- トーンアップ（血色・透明感） ---
  ctx.save();
  ctx.globalCompositeOperation = "soft-light";
  ctx.fillStyle = "rgba(255,214,222,0.30)";
  ctx.fillRect(0, 0, W, H);
  ctx.globalCompositeOperation = "screen";
  ctx.fillStyle = "rgba(255,240,250,0.05)";
  ctx.fillRect(0, 0, W, H);
  ctx.restore();

  // --- 目元ネオンバー ---
  if (state.barOn) neonBar(useLm, W, H);
}

function faceOvalPath(lm, W, H) {
  const p = new Path2D();
  for (let i = 0; i < FACE_OVAL.length; i++) {
    const pt = lm[FACE_OVAL[i]];
    const x = pt.x * W, y = pt.y * H;
    if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
  }
  p.closePath();
  return p;
}

// 縮小→拡大で作る軽量ブラー（Safari含む全ブラウザ対応）
function makeBlur(divisor) {
  const bw = Math.max(8, Math.round(cv.width / divisor));
  const bh = Math.max(8, Math.round(cv.height / divisor));
  blurC.width = bw; blurC.height = bh;
  blurCtx.drawImage(video, 0, 0, bw, bh);
  return blurC;
}

function privacyBlur(W, H) {
  const bw = 24, bh = Math.max(2, Math.round(bw * H / W));
  blurC.width = bw; blurC.height = bh;
  blurCtx.drawImage(video, 0, 0, bw, bh);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(blurC, 0, 0, W, H);
  ctx.fillStyle = "rgba(8,8,16,0.35)";
  ctx.fillRect(0, 0, W, H);
}

function sharpEye(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner], t = lm[eye.top], b = lm[eye.bottom];
  const cx = (o.x + i2.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const rw = Math.hypot((o.x - i2.x) * W, (o.y - i2.y) * H) * 0.85;
  const rh = Math.max(8, Math.abs(b.y - t.y) * H * 1.8);
  sharpRegion(cx, cy, rw, rh, W, H);
}

function sharpMouth(lm, W, H) {
  const l = lm[MOUTH.left], r = lm[MOUTH.right], t = lm[MOUTH.top], b = lm[MOUTH.bottom];
  const cx = (l.x + r.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const mw = Math.hypot((r.x - l.x) * W, (r.y - l.y) * H);
  sharpRegion(cx, cy, mw * 0.78, mw * 0.5, W, H);
}

function sharpRegion(cx, cy, rw, rh, W, H) {
  ctx.save();
  const p = new Path2D();
  p.ellipse(cx, cy, rw, rh, 0, 0, Math.PI * 2);
  ctx.clip(p);
  ctx.globalAlpha = 0.9;
  ctx.drawImage(video, 0, 0, W, H);
  ctx.globalAlpha = 1;
  ctx.restore();
}

function jawShade(lm, W, H) {
  const a = lm[234], b = lm[454];
  const fw = Math.hypot((b.x - a.x) * W, (b.y - a.y) * H);
  const p = new Path2D();
  for (let i = 0; i < JAW.length; i++) {
    const pt = lm[JAW[i]];
    const x = pt.x * W, y = pt.y * H;
    if (i === 0) p.moveTo(x, y); else p.lineTo(x, y);
  }
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "rgba(70,35,30,0.10)";
  ctx.lineWidth = fw * 0.10;
  ctx.shadowColor = "rgba(70,35,30,0.32)";
  ctx.shadowBlur = fw * 0.08;
  ctx.stroke(p);
  ctx.restore();
}

function magnifyEye(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner], t = lm[eye.top], b = lm[eye.bottom];
  const cx = (o.x + i2.x) / 2 * W;
  const cy = (t.y + b.y) / 2 * H;
  const ew = Math.hypot((o.x - i2.x) * W, (o.y - i2.y) * H) * 1.9;
  const eh = Math.max(12, Math.abs(b.y - t.y) * H * 3.2);
  const k = 1.12; // 拡大率（控えめ）
  const sw = ew, sh = eh, dw = ew * k, dh = eh * k;
  const sx = cx - sw / 2, sy = cy - sh / 2;
  const dx = cx - dw / 2, dy = cy - dh / 2;

  eyeC.width = Math.max(2, Math.ceil(dw));
  eyeC.height = Math.max(2, Math.ceil(dh));
  eyeCtx.clearRect(0, 0, eyeC.width, eyeC.height);
  eyeCtx.drawImage(video, sx, sy, sw, sh, 0, 0, dw, dh);
  // 縁を柔らかくフェード
  const g = eyeCtx.createRadialGradient(dw / 2, dh / 2, Math.min(dw, dh) * 0.25, dw / 2, dh / 2, Math.min(dw, dh) * 0.52);
  g.addColorStop(0, "rgba(0,0,0,1)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  eyeCtx.globalCompositeOperation = "destination-in";
  eyeCtx.fillStyle = g;
  eyeCtx.fillRect(0, 0, eyeC.width, eyeC.height);
  eyeCtx.globalCompositeOperation = "source-over";
  ctx.drawImage(eyeC, dx, dy);
}

function eyeCenterPx(eye, lm, W, H) {
  const o = lm[eye.outer], i2 = lm[eye.inner];
  return { x: (o.x + i2.x) / 2 * W, y: (o.y + i2.y) / 2 * H };
}

function roundRectPath(x, y, w, h, r) {
  const p = new Path2D();
  p.moveTo(x + r, y);
  p.lineTo(x + w - r, y);
  p.arcTo(x + w, y, x + w, y + r, r);
  p.lineTo(x + w, y + h - r);
  p.arcTo(x + w, y + h, x + w - r, y + h, r);
  p.lineTo(x + r, y + h);
  p.arcTo(x, y + h, x, y + h - r, r);
  p.lineTo(x, y + r);
  p.arcTo(x, y, x + r, y, r);
  p.closePath();
  return p;
}

function neonBar(lm, W, H) {
  const c = COLORS[state.color];
  const e1 = eyeCenterPx(EYE_R, lm, W, H);
  const e2 = eyeCenterPx(EYE_L, lm, W, H);
  const cx = (e1.x + e2.x) / 2, cy = (e1.y + e2.y) / 2;
  const d = Math.hypot(e2.x - e1.x, e2.y - e1.y);
  const ang = Math.atan2(e2.y - e1.y, e2.x - e1.x);
  const bw = d * 2.35;
  const bh = Math.max(18, d * 0.62);
  const r = bh * 0.35;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(ang);
  const p = roundRectPath(-bw / 2, -bh / 2, bw, bh, r);

  // 本体（黒ガラス）＋外側グロー
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = bh * 0.9;
  ctx.fillStyle = "rgba(10,10,18,0.93)";
  ctx.fill(p);
  ctx.shadowBlur = 0;

  // ガラスの光沢
  const g = ctx.createLinearGradient(0, -bh / 2, 0, bh / 2);
  g.addColorStop(0, "rgba(255,255,255,0.10)");
  g.addColorStop(0.5, "rgba(255,255,255,0.02)");
  g.addColorStop(1, "rgba(255,255,255,0.10)");
  ctx.fillStyle = g;
  ctx.fill(p);

  // ネオン縁取り
  ctx.lineWidth = Math.max(2, bh * 0.08);
  ctx.strokeStyle = c.main;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = bh * 0.6;
  ctx.stroke(p);

  // センターのスキャンライン
  ctx.shadowBlur = 0;
  ctx.strokeStyle = c.sub;
  ctx.globalAlpha = 0.5;
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-bw / 2 + r, 0);
  ctx.lineTo(bw / 2 - r, 0);
  ctx.stroke();
  ctx.restore();
}

// ============================================================
// モードB：アバターモード（実写は一切描画しない）
// ============================================================
function renderModeB(lm, bs, W, H, ts) {
  const c = COLORS[state.color];

  // --- 背景：ナイトグラデ＋グロー＋パーティクル ---
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, "#070812");
  bg.addColorStop(0.6, "#0c1030");
  bg.addColorStop(1, "#151245");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const rg = ctx.createRadialGradient(W / 2, H * 0.45, 10, W / 2, H * 0.45, H * 0.62);
  rg.addColorStop(0, c.glow.replace("0.85", "0.20").replace("0.80", "0.20"));
  rg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = rg;
  ctx.fillRect(0, 0, W, H);

  // 床グリッド（うっすら）
  ctx.save();
  ctx.strokeStyle = "rgba(120,130,255,0.08)";
  ctx.lineWidth = 1;
  for (let i = 1; i <= 6; i++) {
    const y = H * 0.68 + i * i * H * 0.012;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }
  ctx.restore();

  // パーティクル
  ctx.save();
  for (const pt of particles) {
    pt.y -= pt.sp;
    if (pt.y < -0.05) { pt.y = 1.05; pt.x = Math.random(); }
    const tw = 0.35 + 0.3 * Math.sin(ts / 700 + pt.tw);
    ctx.globalAlpha = tw;
    ctx.fillStyle = c.sub;
    ctx.beginPath();
    ctx.arc(pt.x * W, pt.y * H, pt.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // --- アバター駆動値の更新と描画 ---
  updateAvatar(lm, bs, ts);
  drawAvatar(W, H);
}

function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }

function eyeCenterN(eye, lm) {
  const o = lm[eye.outer], i2 = lm[eye.inner];
  return { x: (o.x + i2.x) / 2, y: (o.y + i2.y) / 2 };
}

function gazeFrom(lm) {
  function one(E) {
    const o = lm[E.outer], i2 = lm[E.inner], t2 = lm[E.top], b2 = lm[E.bottom], ir = lm[E.iris];
    const cx = (o.x + i2.x) / 2, cy = (t2.y + b2.y) / 2;
    const w = Math.abs(o.x - i2.x) || 0.001;
    const h = Math.abs(b2.y - t2.y) || 0.001;
    return {
      x: clamp((ir.x - cx) / (w * 0.5), -1, 1),
      y: clamp((ir.y - cy) / (h * 0.9), -1, 1)
    };
  }
  const a = one(EYE_R), b = one(EYE_L);
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
}

function updateAvatar(lm, bs, ts) {
  const t = AV.target;
  if (lm && state.faceOK) {
    const nose = lm[NOSE_TIP];
    const e1 = eyeCenterN(EYE_R, lm), e2 = eyeCenterN(EYE_L, lm);
    const midx = (e1.x + e2.x) / 2, midy = (e1.y + e2.y) / 2;
    const d = Math.hypot(e2.x - e1.x, e2.y - e1.y) || 0.001;
    t.x = 0.5 + (nose.x - 0.5) * 0.5;
    t.y = 0.46 + (nose.y - 0.5) * 0.4;
    t.roll = Math.atan2(e2.y - e1.y, e2.x - e1.x);
    t.yaw = clamp(((nose.x - midx) / d) * 1.6, -1, 1);
    t.pitch = clamp((((nose.y - midy) / d) - 0.62) * 2.0, -1, 1);
    t.blinkL = bs.eyeBlinkLeft || 0;
    t.blinkR = bs.eyeBlinkRight || 0;
    t.jaw = clamp((bs.jawOpen || 0) * 1.5, 0, 1);
    t.smile = clamp(((bs.mouthSmileLeft || 0) + (bs.mouthSmileRight || 0)) * 0.7, 0, 1);
    t.browUp = bs.browInnerUp || 0;
    t.browDn = ((bs.browDownLeft || 0) + (bs.browDownRight || 0)) / 2;
    const gz = gazeFrom(lm);
    t.gx = gz.x;
    t.gy = gz.y;
  } else {
    // スタンバイ（自動まばたき＋ゆらぎ）
    t.x = 0.5; t.y = 0.46;
    t.roll = Math.sin(ts / 1600) * 0.05;
    t.yaw = Math.sin(ts / 2300) * 0.25;
    t.pitch = Math.sin(ts / 2900) * 0.12;
    const ph = (ts % 3600) / 3600;
    const bl = ph > 0.93 ? Math.sin((ph - 0.93) / 0.07 * Math.PI) : 0;
    t.blinkL = bl; t.blinkR = bl;
    t.jaw = 0; t.smile = 0.25;
    t.browUp = 0; t.browDn = 0;
    t.gx = Math.sin(ts / 2100) * 0.3; t.gy = 0;
  }
  const s = AV.cur, k = 0.35;
  for (const key of Object.keys(t)) s[key] += (t[key] - s[key]) * k;
}

function ellipseFill(x, y, rx, ry, fill) {
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawAvatar(W, H) {
  const s = AV.cur;
  const c = COLORS[state.color];
  const f = H * 0.36;        // 顔の基準サイズ
  const hw = f * 0.42;       // 顔の半幅
  const cx = s.x * W, cy = s.y * H;

  ctx.save();
  ctx.translate(cx, cy);

  // --- 体（回転しない） ---
  ctx.fillStyle = "#171d33";
  const body = roundRectPath(-hw * 1.75, f * 0.52, hw * 3.5, f * 0.95, f * 0.18);
  ctx.fill(body);
  // ネオンのリムライト
  ctx.save();
  ctx.strokeStyle = c.main;
  ctx.globalAlpha = 0.55;
  ctx.lineWidth = f * 0.014;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = f * 0.06;
  ctx.beginPath();
  ctx.moveTo(-hw * 1.55, f * 0.72);
  ctx.quadraticCurveTo(-hw * 1.75, f * 1.0, -hw * 1.5, f * 1.4);
  ctx.stroke();
  ctx.restore();
  // 首
  ctx.fillStyle = "#f2c9ae";
  ctx.fillRect(-f * 0.09, f * 0.36, f * 0.18, f * 0.22);

  // --- 頭（首から上はロールで回転） ---
  ctx.save();
  ctx.rotate(s.roll * 0.7);

  // 後ろ髪
  ellipseFill(0, -f * 0.06, hw * 1.18, f * 0.62, "#241a17");

  // 顔
  ctx.fillStyle = "#ffe0cd";
  ctx.beginPath();
  ctx.moveTo(0, -f * 0.5);
  ctx.bezierCurveTo(hw * 0.95, -f * 0.5, hw * 1.0, -f * 0.05, hw * 0.86, f * 0.16);
  ctx.bezierCurveTo(hw * 0.72, f * 0.38, f * 0.16, f * 0.5, 0, f * 0.52);
  ctx.bezierCurveTo(-f * 0.16, f * 0.5, -hw * 0.72, f * 0.38, -hw * 0.86, f * 0.16);
  ctx.bezierCurveTo(-hw * 1.0, -f * 0.05, -hw * 0.95, -f * 0.5, 0, -f * 0.5);
  ctx.closePath();
  ctx.fill();

  // ほお（チーク）
  const blushA = 0.10 + s.smile * 0.12;
  ctx.globalAlpha = blushA;
  ellipseFill(-f * 0.30, f * 0.16, f * 0.075, f * 0.04, "#ff7890");
  ellipseFill(f * 0.30, f * 0.16, f * 0.075, f * 0.04, "#ff7890");
  ctx.globalAlpha = 1;

  // --- パーツ群（ヨー/ピッチで視差シフト＝擬似3D） ---
  ctx.save();
  ctx.translate(s.yaw * f * 0.09, s.pitch * f * 0.07);

  const eyeY = -f * 0.055;

  // 眉
  drawBrow(-1, f, s);
  drawBrow(1, f, s);

  // 目
  drawEye(-1, f, s, eyeY);
  drawEye(1, f, s, eyeY);

  // 鼻（さりげなく）
  ctx.strokeStyle = "rgba(190,110,85,0.35)";
  ctx.lineWidth = f * 0.012;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(f * 0.012, f * 0.06);
  ctx.quadraticCurveTo(f * 0.03, f * 0.15, f * 0.006, f * 0.17);
  ctx.stroke();

  // 口
  drawMouth(f, s);

  ctx.restore(); // パーツ群

  // 前髪（最前面）
  hairFront(f, hw);

  ctx.restore(); // 頭
  ctx.restore(); // アバター全体
}

function drawBrow(dir, f, s) {
  const y = -f * 0.16 - s.browUp * f * 0.045 + s.browDn * f * 0.02;
  ctx.strokeStyle = "#3a2b24";
  ctx.lineWidth = f * 0.028;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(dir * f * 0.075, y + f * 0.012 + s.browDn * f * 0.012);
  ctx.quadraticCurveTo(dir * f * 0.17, y - f * 0.028, dir * f * 0.27, y + f * 0.02);
  ctx.stroke();
}

function drawEye(dir, f, s, eyeY) {
  const exc = dir * f * 0.165;
  const b = dir < 0 ? s.blinkR : s.blinkL;
  const openness = clamp(1 - b * 1.15, 0.02, 1);
  const w2 = f * 0.085;
  const h2 = f * 0.055 * openness;

  ctx.save();
  ctx.translate(exc, eyeY);
  if (openness < 0.14) {
    // 閉じ目
    ctx.strokeStyle = "#3a2b24";
    ctx.lineWidth = f * 0.016;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-w2, 0);
    ctx.quadraticCurveTo(0, f * 0.02, w2, 0);
    ctx.stroke();
  } else {
    // 白目
    ellipseFill(0, 0, w2, h2, "#ffffff");
    // 虹彩＋瞳（視線連動）
    const ir = h2 * 1.15;
    const ix = clamp(s.gx, -1, 1) * Math.max(0, w2 - ir * 0.7);
    const iy = clamp(s.gy, -1, 1) * (h2 * 0.5);
    ctx.save();
    const clipP = new Path2D();
    clipP.ellipse(0, 0, w2, h2, 0, 0, Math.PI * 2);
    ctx.clip(clipP);
    const g = ctx.createRadialGradient(ix, iy - ir * 0.3, ir * 0.15, ix, iy, ir);
    g.addColorStop(0, "#8a5a37");
    g.addColorStop(0.55, "#4c2f1c");
    g.addColorStop(1, "#231208");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(ix, iy, ir, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#140a04";
    ctx.beginPath();
    ctx.arc(ix, iy, ir * 0.45, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.arc(ix - ir * 0.3, iy - ir * 0.35, ir * 0.16, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    // 上まつげ
    ctx.strokeStyle = "#2c1f19";
    ctx.lineWidth = f * 0.018;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-w2, -h2 * 0.35);
    ctx.quadraticCurveTo(0, -h2 * 1.35, w2, -h2 * 0.25);
    ctx.stroke();
  }
  ctx.restore();
}

function drawMouth(f, s) {
  const my = f * 0.27;
  const mw = f * 0.155 * (1 + s.smile * 0.35);
  ctx.save();
  ctx.translate(0, my);
  if (s.jaw < 0.06) {
    // 閉じ口（微笑みカーブ）
    const lift = s.smile * f * 0.045;
    ctx.strokeStyle = "#b0575e";
    ctx.lineWidth = f * 0.02;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-mw, -lift);
    ctx.quadraticCurveTo(0, f * 0.03 - lift * 0.3, mw, -lift);
    ctx.stroke();
  } else {
    // 開き口（口パク）
    const oh = f * (0.03 + s.jaw * 0.13);
    ctx.fillStyle = "#75242f";
    ctx.beginPath();
    ctx.moveTo(-mw, -oh * 0.15);
    ctx.quadraticCurveTo(0, -oh * 0.55, mw, -oh * 0.15);
    ctx.quadraticCurveTo(mw * 0.6, oh * 0.85, 0, oh);
    ctx.quadraticCurveTo(-mw * 0.6, oh * 0.85, -mw, -oh * 0.15);
    ctx.closePath();
    ctx.fill();
    // 舌
    ctx.fillStyle = "rgba(214,94,104,0.85)";
    ctx.beginPath();
    ctx.ellipse(0, oh * 0.55, mw * 0.5, oh * 0.38, 0, 0, Math.PI * 2);
    ctx.fill();
    // 上の歯
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.beginPath();
    ctx.moveTo(-mw * 0.8, -oh * 0.28);
    ctx.quadraticCurveTo(0, -oh * 0.5, mw * 0.8, -oh * 0.28);
    ctx.quadraticCurveTo(0, -oh * 0.05, -mw * 0.8, -oh * 0.28);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function hairFront(f, hw) {
  ctx.fillStyle = "#292019";
  ctx.beginPath();
  ctx.moveTo(-hw * 1.04, f * 0.10);
  ctx.quadraticCurveTo(-hw * 1.16, -f * 0.30, -hw * 0.62, -f * 0.52);
  ctx.quadraticCurveTo(0, -f * 0.70, hw * 0.62, -f * 0.52);
  ctx.quadraticCurveTo(hw * 1.16, -f * 0.30, hw * 1.04, f * 0.10);
  ctx.quadraticCurveTo(hw * 0.86, -f * 0.02, hw * 0.74, -f * 0.16);
  // 前髪ギザギザ（右→左）
  const tips  = [0.55, 0.30, 0.05, -0.22, -0.48];
  const tipY  = [-0.02, -0.10, 0.02, -0.12, -0.04];
  let prevX = hw * 0.74;
  for (let i = 0; i < tips.length; i++) {
    const tx = hw * tips[i], ty = f * tipY[i];
    ctx.quadraticCurveTo(prevX * 0.5 + tx * 0.5, ty + f * 0.06, tx, ty);
    const nbx = i < tips.length - 1 ? (tx + hw * tips[i + 1]) / 2 : -hw * 0.74;
    const nby = -f * 0.18;
    ctx.quadraticCurveTo(tx - hw * 0.04, nby, nbx, nby);
    prevX = nbx;
  }
  ctx.quadraticCurveTo(-hw * 0.86, -f * 0.02, -hw * 1.04, f * 0.10);
  ctx.closePath();
  ctx.fill();
  // ハイライト
  ctx.strokeStyle = "rgba(133,96,66,0.55)";
  ctx.lineWidth = f * 0.012;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-hw * 0.45, -f * 0.50);
  ctx.quadraticCurveTo(-hw * 0.1, -f * 0.60, hw * 0.35, -f * 0.50);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-hw * 0.55, -f * 0.40);
  ctx.quadraticCurveTo(-hw * 0.15, -f * 0.50, hw * 0.2, -f * 0.42);
  ctx.stroke();
}

// ============================================================
// HUD（ロゴ・ステータス）※ミラーの影響を受けない層
// ============================================================
function drawLogo(W, H) {
  const c = COLORS[state.color];
  ctx.save();
  const fs = Math.max(16, Math.round(H * 0.035));
  ctx.font = "italic 900 " + fs + "px 'Arial Black', 'Hiragino Sans', sans-serif";
  ctx.textAlign = "right";
  ctx.textBaseline = "bottom";
  const x = W - fs * 0.8, y = H - fs * 0.6;
  ctx.shadowColor = c.glow;
  ctx.shadowBlur = fs * 0.8;
  ctx.fillStyle = "#ffffff";
  ctx.fillText("STUDIO J", x, y);
  ctx.shadowBlur = 0;
  ctx.strokeStyle = c.main;
  ctx.lineWidth = 1;
  ctx.globalAlpha = 0.9;
  ctx.strokeText("STUDIO J", x, y);
  ctx.restore();
}

function drawStatus(W, H) {
  // モードAでロスト中は中央に案内（これは常時表示）
  if (state.mode === "A" && !state.faceOK) {
    ctx.save();
    const fs = Math.max(18, Math.round(H * 0.04));
    ctx.font = "900 " + fs + "px 'Arial Black', 'Hiragino Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowColor = "rgba(34,230,255,0.9)";
    ctx.shadowBlur = fs * 0.7;
    ctx.fillStyle = "#ffffff";
    ctx.fillText("PRIVACY GUARD", W / 2, H * 0.46);
    ctx.shadowBlur = 0;
    ctx.font = Math.round(fs * 0.5) + "px 'Hiragino Sans', sans-serif";
    ctx.fillStyle = "rgba(220,225,255,0.85)";
    ctx.fillText("顔を検出するまで自動ブラー中", W / 2, H * 0.46 + fs);
    ctx.restore();
  }

  // ステータスピル（UI表示中のみ＝配信画面には残らない）
  if (!uiVisible) return;
  ctx.save();
  const pw = 168, ph = 30;
  ctx.fillStyle = "rgba(10,12,24,0.72)";
  ctx.fill(roundRectPath(12, 12, pw, ph, 15));
  ctx.fillStyle = state.faceOK ? "#3dff9a" : "#ff5d6c";
  ctx.beginPath();
  ctx.arc(30, 27, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#dfe2ff";
  ctx.font = "600 13px 'Hiragino Sans', monospace, sans-serif";
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText((state.faceOK ? "TRACK OK" : "LOST") + " / " + fps + "fps", 44, 28);
  ctx.restore();
}

// ============================================================
// UIイベント
// ============================================================
function setMode(m) {
  state.mode = m;
  $("mA").classList.toggle("on", m === "A");
  $("mB").classList.toggle("on", m === "B");
  $("rowA").classList.toggle("hidden", m !== "A");
}

$("mA").addEventListener("click", () => setMode("A"));
$("mB").addEventListener("click", () => setMode("B"));
$("ckBar").addEventListener("change", (e) => { state.barOn = e.target.checked; });
$("ckMirror").addEventListener("change", (e) => { state.mirror = e.target.checked; });
$("rgBihada").addEventListener("input", (e) => { state.bihada = Number(e.target.value); });

document.querySelectorAll(".sw").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".sw").forEach((b) => b.classList.remove("on"));
    btn.classList.add("on");
    state.color = btn.dataset.c;
  });
});

$("btnFs").addEventListener("click", () => {
  const el = $("stage");
  if (!document.fullscreenElement) {
    if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
  } else if (document.exitFullscreen) {
    document.exitFullscreen();
  }
});

$("btnReload").addEventListener("click", () => location.reload());

// コントロールの自動非表示
function pokeUI() {
  uiVisible = true;
  document.body.classList.remove("ui-hidden");
  clearTimeout(uiTimer);
  uiTimer = setTimeout(() => {
    if (state.running) {
      uiVisible = false;
      document.body.classList.add("ui-hidden");
    }
  }, 3200);
}
["pointermove", "pointerdown", "touchstart", "keydown"].forEach((ev) =>
  window.addEventListener(ev, pokeUI, { passive: true })
);

// ---- スタート ----
$("btnStart").addEventListener("click", async () => {
  $("hudStart").classList.add("hidden");
  $("loading").classList.remove("hidden");
  try {
    await Promise.all([initLandmarker(), startCamera()]);
    $("loading").classList.add("hidden");
    state.running = true;
    pokeUI();
    requestAnimationFrame(loop);
  } catch (err) {
    $("loading").classList.add("hidden");
    showError(err);
  }
});

console.log("STUDIO J V-CAM v" + VERSION + " — on-device processing only");
